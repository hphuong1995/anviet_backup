import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  errorCheck: boolean;
  errorMessage: string;

  constructor(private formBuilder : FormBuilder,
                private userService : UserService,
                private router: Router,) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      re_password:['', Validators.required],
      // company: ['', Validators.required],
      phoneNumber: ['', Validators.required && Validators.pattern('[0-9]+')]
    });
  }

  get f() { return this.registerForm.controls; }

  onSubmit(){
    if(this.f.email.value === '' || this.f.password.value === '' || this.f.phoneNumber.value === ''){
      this.errorCheck = true;
      this.errorMessage = "At least one field is missing";
      return;
    }
    if(this.f.password.value === this.f.re_password.value){
      this.errorCheck = false;
      var newUser = {'email': this.f.email.value,
                     'password':this.f.password.value,
                     // 'company' : this.f.company.value,
                     'phone' : this.f.phoneNumber.value};
      this.userService.userRegister( newUser ).subscribe( data =>{
        console.log(data);
        var retData : any = data;
        if(retData.valid === true){
          this.router.navigate(['login']);
        }
      });
    }
    else{
      this.errorCheck = true;
      this.errorMessage = "Two password fields are not the same";
    }
  }

}
