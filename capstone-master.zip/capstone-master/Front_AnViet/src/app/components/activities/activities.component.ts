import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { UserService } from '../../services/user.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';


export interface Activity {
  company: string
  warehouse: string
  product: string
  amount: string
  date: string
  type: string
  activity_id: string
  mng_name: string
  driver_plate: string
  status: string
}

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.css']
})
export class ActivitiesComponent implements OnInit {

  constructor(private dataService : DataService,
              private userService : UserService,
              private _location: Location,
              private router : Router,
              private formBuilder : FormBuilder) { }


  displayedColumns: string[] = ['date', 'type', 'activity_id', 'company','warehouse', 'product', 'amount', 'mng_name','driver_plate','status'];
  dataSource: MatTableDataSource<Activity>;
  activities: Activity[];
  filterForm: FormGroup;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  filterSearchObj = {
    activity_warehouse: null,
    activity_product: null,
    activity_company: null,
    startDate: null,
    endDate:null,
    activity_type: null,
    activity_code: null,
    activity_status: null
  }

  ngOnInit() {

    this.filterForm = this.formBuilder.group({
      activity_warehouse: [''],
      activity_product: [''],
      activity_company: [''],
      activity_type:[''],
      activity_code:[''],
      activity_status:['']
    });

    if(!(this.userService.isAdmAccount() || this.userService.isMngAccount())){
      this.router.navigate(['login']);
      return;
    }

    this.filterChange();

  }

  get filterFormControl() { return this.filterForm.controls; }

  filterChange(){
      if(this.filterFormControl.activity_warehouse.value !== '' || this.filterFormControl.activity_warehouse.value !== this.filterSearchObj.activity_warehouse){
        this.filterSearchObj.activity_warehouse = this.filterFormControl.activity_warehouse.value.trim();
      }
      if(this.filterFormControl.activity_product.value !== '' || this.filterFormControl.activity_product.value !== this.filterSearchObj.activity_product){
        this.filterSearchObj.activity_product = this.filterFormControl.activity_product.value.trim();
      }
      if(this.filterFormControl.activity_company.value !== '' && this.filterFormControl.activity_company.value !== this.filterSearchObj.activity_company){
        this.filterSearchObj.activity_company = this.filterFormControl.activity_company.value.trim();
      }
      if(this.filterFormControl.activity_code.value !== '' && this.filterFormControl.activity_code.value !== this.filterSearchObj.activity_code){
        this.filterSearchObj.activity_code = this.filterFormControl.activity_code.value.trim();
      }
      if(this.filterFormControl.activity_type.value && this.filterFormControl.activity_type.value !== this.filterSearchObj.activity_type){
        this.filterSearchObj.activity_type = this.filterFormControl.activity_type.value.trim();
      }
      if(this.filterFormControl.activity_status.value && this.filterFormControl.activity_status.value !== this.filterSearchObj.activity_status){
        this.filterSearchObj.activity_status = this.filterFormControl.activity_status.value.trim();
      }
      if(this.filterFormControl.activity_type.value === ''){
        this.filterSearchObj.activity_type = null;
      }
      if(this.filterFormControl.activity_status.value === ''){
        this.filterSearchObj.activity_status = null;
      }

      this.generateTableData(this.filterSearchObj);
  }


  generateTableData( filterSearchObj){
    this.dataService.getAllActivitiesByAdmMng( filterSearchObj ).subscribe( data =>{
      let retData : any = data;
      this.activities = retData.map( activity =>  convertActivity( activity));
      this.dataSource = new MatTableDataSource(this.activities);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    });
  }


  startDateChange(type: string, event: MatDatepickerInputEvent<Date>): void {
    this.filterSearchObj.startDate = event.value;
    this.filterChange();
  }

  endDateChange(type: string, event: MatDatepickerInputEvent<Date>): void {
    this.filterSearchObj.endDate = event.value;
    this.filterChange();
  }
}




/** Builds and returns a new User. */
function convertActivity(activity): Activity {
  return {
    company: activity.companyShortName,
    product: activity.prodCode ,
    warehouse: activity.warehouseCode,
    amount: activity.activity_amount + " " + activity.unit_name,
    date: activity.activity_date.substr(3,12),
    type: activity.activity_type,
    activity_id: activity.aid,
    mng_name: activity.shortName,
    driver_plate: activity.req_driver_plate,
    status: activity.activity_status
  };
}
