import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { UserService } from '../../services/user.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatDatepicker} from '@angular/material/datepicker';
import {Moment} from 'moment';

import * as _moment from 'moment';

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-bills',
  templateUrl: './bills.component.html',
  styleUrls: ['./bills.component.css'],
  providers: [
   {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
   {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
 ],
})
export class BillsComponent implements OnInit {

  billForm: FormGroup;
  filteredCompanyOptions: Observable<string[]>;
  currentCompanySet: any[] = [];

  currentProcessingCompanies : any[] = [];
  currentBills: any = {};

  constructor( private dataService : DataService,
               private userService : UserService,
               private _location: Location,
               private router : Router,
               private formBuilder : FormBuilder) {

     this.billForm = this.formBuilder.group({
       month: new FormControl(_moment()),
       company:['']
     });
  }

  ngOnInit() {
    this.filteredCompanyOptions = this.billFormControl.company.valueChanges
      .pipe(
        startWith(''),
        map( value  => this._filterCompany(value))
      );
      this.currentProcessingCompanies = this.userService.getAllRelatedCompanies();
    if(this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    if(this.userService.isAdmAccount()){
      this.dataService.getAllCompaniesByAdmOrMng().subscribe( companies =>{
        let retData: any = companies;
        this.currentCompanySet = retData;
      })
    }
  }

  generateBill(){
    let chosenStr = this.billFormControl.month.value.format('MM/YYYY');
    chosenStr = chosenStr.substr(0, chosenStr.length - 5) + '/10/' + chosenStr.substr(chosenStr.length - 4);
    let chosenDate = new Date(chosenStr);
    let startDate = new Date(chosenDate.getFullYear(), chosenDate.getMonth(), 1);
    let endDate = new Date(chosenDate.getFullYear(), chosenDate.getMonth() + 1, 0);

    if(this.billFormControl.company.value === ""){
      return;
    }

    let billObj = {
      company: this.billFormControl.company.value,
      startDate: startDate,
      endDate: endDate
    };

    this.dataService.generateBillByAdmOrCus(billObj).subscribe(bills =>{
      this.currentBills = bills;
      this.currentBills.totalStoragePayment = 0;
      this.currentBills.total_import_normal = 0;
      this.currentBills.total_import_overtime = 0;
      this.currentBills.total_import_holiday = 0;
      this.currentBills.total_export_normal = 0;
      this.currentBills.total_export_overtime = 0;
      this.currentBills.total_export_holiday = 0;
      this.currentBills.totalBeginInventory = 0;
      this.currentBills.totalPortPayment = 0;

      this.currentBills.bills.forEach( bill =>{
        let total_amount = parseInt(bill.begin_amount) + parseInt(bill.import_normal) + parseInt(bill.import_over_time) + parseInt(bill.import_holiday);
        bill.storagePayment = total_amount * parseFloat(bill.daily_storageFee);
        bill.portPayment = ((parseInt(bill.import_normal) + parseInt(bill.export_normal)) * parseFloat(bill.daily_portFee)) +
                          ((parseInt(bill.import_over_time) + parseInt(bill.export_over_time)) * parseFloat(bill.daily_portFee) * 1.5) +
                          ((parseInt(bill.import_holiday) + parseInt(bill.export_holiday)) * parseFloat(bill.daily_portFee) * 2.0);

        bill.storagePayment = parseFloat(bill.storagePayment).toFixed(2);
        bill.portPayment = parseFloat(bill.portPayment).toFixed(2);
        this.currentBills.totalPortPayment = this.currentBills.totalPortPayment + bill.portPayment;
        this.currentBills.totalStoragePayment = this.currentBills.totalStoragePayment + (total_amount* parseFloat(bill.daily_storageFee));
        this.currentBills.total_import_normal = this.currentBills.total_import_normal + parseInt(bill.import_normal);
        this.currentBills.total_import_overtime = this.currentBills.total_import_overtime + parseInt(bill.import_over_time);
        this.currentBills.total_import_holiday = this.currentBills.total_import_holiday + parseInt(bill.import_holiday);
        this.currentBills.total_export_normal = this.currentBills.total_export_normal + parseInt(bill.export_normal);
        this.currentBills.total_export_overtime = this.currentBills.total_export_overtime+ parseInt(bill.export_over_time);
        this.currentBills.total_export_holiday = this.currentBills.total_export_holiday + parseInt(bill.export_holiday);
        this.currentBills.totalBeginInventory = this.currentBills.totalBeginInventory + parseInt(bill.begin_amount);
      });
      this.currentBills.totalPortPayment = parseFloat(this.currentBills.totalPortPayment).toFixed(2);
      this.currentBills.totalStoragePayment = parseFloat(this.currentBills.totalStoragePayment).toFixed(2);
      this.currentBills.totalPaymentBeforeTax = (parseFloat(this.currentBills.totalPortPayment) + parseFloat(this.currentBills.totalStoragePayment)).toFixed(2);
      this.currentBills.tax = (parseFloat(this.currentBills.totalPaymentBeforeTax)/10.0).toFixed(2);
      this.currentBills.totalPaymentAfterTax = (parseFloat(this.currentBills.tax) + parseFloat(  this.currentBills.totalPaymentBeforeTax)).toFixed(2);
      let check = this.currentBills.bills;
      //console.log(check);
      check.sort(this.compareBillDate);
      //console.log(check);
    });
  }

  compareBillDate(a, b){
    let aDate = new Date(a.daily_bill_date).getTime();
    let bDate = new Date(b.daily_bill_date).getTime();
    if(aDate > bDate){
      return 1;
    }
    if(bDate > aDate){
      return -1;
    }
    return 0;
  }

  private _filterCompany(value): string[] {
    const filterValue = value.toLowerCase();
    return this.currentCompanySet.filter(company => company.companyShortName.toLowerCase().includes(filterValue));
  }

  chosenYearHandler(normalizedYear: Moment) {
    const ctrlValue = this.billFormControl.month.value;
    ctrlValue.year(normalizedYear.year());
    this.billFormControl.month.setValue(ctrlValue);
  }

  chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.billFormControl.month.value;
    ctrlValue.month(normalizedMonth.month());
    this.billFormControl.month.setValue(ctrlValue);
    datepicker.close();
  }

  get billFormControl() { return this.billForm.controls; }

}
