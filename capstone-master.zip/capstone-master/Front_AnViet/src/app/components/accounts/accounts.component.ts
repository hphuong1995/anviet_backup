import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';


export interface UserData {
  shortName: string
  type: string
  uid: string
}

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {
  displayedColumns: string[] = ['name', 'role'];

  dataSource: MatTableDataSource<UserData>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  accounts: UserData[];

  constructor( private _location: Location,
    private dataService : DataService,
    private router: Router,
    private userService : UserService) {

    //this.dataSource = new MatTableDataSource(this.accounts);

  }

  ngOnInit(){
    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    this.dataService.admOrMngGetAllAccounts().subscribe( data =>{
      let retData : any = data;
      this.accounts = retData.map( account =>  convertUser( account));
      this.dataSource = new MatTableDataSource(this.accounts);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  ngAfterViewInit() {

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}

/** Builds and returns a new User. */
function convertUser(account): UserData {
  let convertType : string;
  if(account.type === '0'){
    convertType = "Customer"
  }
  else if(account.type === '1'){
    convertType = "Manager"
  }
  else if(account.type === '2'){
    convertType = "Administrator"
  }
  else{
    //NO ELSE
  }

  return {
    shortName: account.shortName,
    type: convertType,
    uid: account.uid,
  };
}
