export class Account {
  accountId: string;
  name:	string;
  status:	string;
  email: string;
  phone: string[];
  type:	string;
  inventory: string;
  storageFee:	string;
  portFee: string;
}
