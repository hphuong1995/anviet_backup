import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';


export interface Employee {
  shortName: string
  type: string
  uid: string
  viewBill: string
  sendRequest: string
}
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  displayedColumns: string[] = ['name', 'viewBill', 'sendRequest'];

  dataSource: MatTableDataSource<Employee>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  employees: Employee[];

  constructor( private data: DataService,
              private userService: UserService,
              private dataService: DataService,
              private route:ActivatedRoute,
              private _location: Location,
              private router: Router) {

    //this.dataSource = new MatTableDataSource(this.accounts);

  }

  ngOnInit(){
    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    this.dataService.admGetAllEmployeesOfCompany( this.route.snapshot.params['cid'] ).subscribe( data =>{
      let retData : any = data;
      this.employees = retData.map( account =>  convertUser( account));
      this.dataSource = new MatTableDataSource(this.employees);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  ngAfterViewInit() {

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  UpdateRight( uid: string){

  }

  updateViewBill(uid, viewBillRight){
    let reqObj : any = {};
    if(viewBillRight === '1'){
      reqObj.viewBill = '0';
    }
    else{
      reqObj.viewBill = '1';
    }
    this.dataService.updateCustomerRight(this.route.snapshot.params['cid'], uid, reqObj).subscribe( data =>{
      let retData : any = data;
      this.employees = retData.map( account =>  convertUser( account));
      this.dataSource = new MatTableDataSource(this.employees);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  updateSendRequest(uid, sendRequestRight){
    let reqObj : any = {};
    if(sendRequestRight === '1'){
      reqObj.sendRequest = '0';
    }
    else{
      reqObj.sendRequest = '1';
    }
    this.dataService.updateCustomerRight(this.route.snapshot.params['cid'], uid, reqObj).subscribe( data =>{
      let retData : any = data;
      this.employees = retData.map( account =>  convertUser( account));
      this.dataSource = new MatTableDataSource(this.employees);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
}

  /** Builds and returns a new User. */
function convertUser(employee): Employee {

  return {
    shortName: employee.shortName,
    type: employee.type,
    uid: employee.uid,
    viewBill: employee.viewBill || '0',
    sendRequest: employee.sendRequest || '0',
  };
}
