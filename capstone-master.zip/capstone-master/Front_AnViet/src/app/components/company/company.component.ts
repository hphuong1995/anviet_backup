import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  currentCompany: any;

  companyName : string;
  company_email : string;
  company_phone: string;
  taxCode : string;
  portFee : string;
  storageFee : string;
  shortName : string;
  address: string;

  editForm: FormGroup;

  constructor(private data: DataService,
              private userService: UserService,
              private dataService: DataService,
              private formBuilder : FormBuilder,
              private route:ActivatedRoute,
              private _location: Location,
              private router: Router) { }

  ngOnInit() {
    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }
    // if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
    //   this.router.navigate(['account']);
    //   return;
    // }

    this.editForm = this.formBuilder.group({
      companyName : '',
      company_email : '',
      company_phone : '',
      taxCode : '',
      portFee : '',
      storageFee : '',
      shortName : '',
      address: ''
    });
    if(this.userService.isAdmAccount()){
      this.dataService.getACompanyByAdm(this.route.snapshot.params['cid']).subscribe (data=>{
        this.currentCompany = data[0];
        this.updateDisplay();
      });
    }
    else if(this.userService.isMngAccount()){
      this.dataService.getACompanyByMng(this.route.snapshot.params['cid']).subscribe (data=>{
        this.currentCompany = data[0];
        this.updateDisplay();
      });
    }
    else{
      this.dataService.getACompanyByCus(this.route.snapshot.params['cid']).subscribe (data=>{
        this.currentCompany = data[0];
        this.updateDisplay();
      });
    }
  }

  updateDisplay(){
    this.editForm = this.formBuilder.group({
      companyName : [this.currentCompany.companyName, Validators.required],
      company_email : [this.currentCompany.company_email, Validators.required],
      company_phone : [this.currentCompany.company_phone, Validators.required],
      taxCode : [this.currentCompany.taxCode, Validators.required],
      portFee : [this.currentCompany.portFee, Validators.required],
      storageFee : [this.currentCompany.storageFee, Validators.required],
      shortName : [this.currentCompany.companyShortName, Validators.required],
      address: [this.currentCompany.address, Validators.required]
    });

    this.companyName = this.currentCompany.companyName;
    this.company_email = this.currentCompany.company_email;
    this.company_phone = this.currentCompany.company_phone;
    this.taxCode = this.currentCompany.taxCode;
    this.portFee = this.currentCompany.portFee;
    this.storageFee = this.currentCompany.storageFee;
    this.shortName = this.currentCompany.companyShortName;
    this.address = this.currentCompany.address;
  }

  get formControl() { return this.editForm.controls; }


  saveEditCompany(){
    let updatedInfo: any = {
      cid: this.currentCompany.cid,
      companyName : this.formControl.companyName.value,
      company_email : this.formControl.company_email.value,
      company_phone : this.formControl.company_phone.value,
      taxCode : this.formControl.taxCode.value,
      portFee : this.formControl.portFee.value,
      storageFee : this.formControl.storageFee.value,
      shortName : this.formControl.shortName.value,
      address: this.formControl.address.value
    };


    //updatedInfo.type = this.currentUser.type;
    this.dataService.editCompanyInfoByAdmin(updatedInfo).subscribe( data =>{
      this.currentCompany = data[0];
      this.updateDisplay();
      this.ngOnInit();
    });
  }

}
