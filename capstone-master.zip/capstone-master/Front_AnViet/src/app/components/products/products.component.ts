import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


export interface Product {
  productName: string
  productCode: string
  pid :string
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  displayedColumns: string[] = ['productCode', 'productName','action'];

  dataSource: MatTableDataSource<Product>;

  products: Product[] = [];

  createProductForm: FormGroup;
  editProductForm: FormGroup;

  currentDeleteProduct: any = {};

  currentProductView: any ={};

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _location: Location,
              private dataService : DataService,
              private router: Router,
              private userService : UserService,
              private formBuilder : FormBuilder) {

    this.createProductForm = this.formBuilder.group({
      prodName: ['',Validators.required],
      prodCode: ['',Validators.required],
    });

    this.editProductForm = this.formBuilder.group({
      prodCode: ['',Validators.required],
      prodName: ['',Validators.required],
    });
  }

  ngOnInit() {

    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    this.dataService.getAllProdsByAdmOrMng().subscribe( data =>{
      let retData : any = data;
      this.products = retData.map( products =>  convertProduct( products));
      this.dataSource = new MatTableDataSource(this.products);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  get createFormControl() { return this.createProductForm.controls; }
  get editFormControl(){ return this.editProductForm.controls;}

  createProduct(){
    let newProdObj = {
      prodName: this.createFormControl.prodName.value,
      prodCode: this.createFormControl.prodCode.value,
    };

    this.dataService.createProduct(newProdObj).subscribe( data =>{
      let retData : any = data;
      this.products = retData.map( products =>  convertProduct( products));
      this.dataSource = new MatTableDataSource(this.products);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.createFormControl.prodName.setValue('');
      this.createFormControl.prodCode.setValue('');
    });
  }

  viewProduct( row){
    this.currentProductView = row;
    this.editProductForm = this.formBuilder.group({
      prodName: [this.currentProductView.productName,Validators.required],
      prodCode: [this.currentProductView.productCode,Validators.required],
    });
  }

  submitEditProduct(){
    let updateObj = {
      pid: this.currentProductView.pid,
      prodName: this.editFormControl.prodName.value,
      prodCode: this.editFormControl.prodCode.value,
    };

    this.dataService.updateProduct( updateObj).subscribe( data =>{
      let retData : any = data;
      this.products = retData.map( products =>  convertProduct( products));
      this.dataSource = new MatTableDataSource(this.products);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  checkCreate(){
    if(this.createFormControl.prodName.value === "" || this.createFormControl.prodCode.value ===""){
      return false;
    }
    if(this.checkProductCode()){
      return false;
    }
      return true;
  }

  checkProductCode(){
    let flag : boolean = false;
    this.products.forEach( prod =>{
      if(prod.productCode === this.createFormControl.prodCode.value){
        flag = true;
      }
    });
    return flag;
  }

  setDeleteProduct(pid){
    console.log(pid);
    this.currentDeleteProduct = pid;
  }

  deleteProduct(){
    this.dataService.deleteProduct(this.currentDeleteProduct.pid).subscribe(data=>{
      console.log(data);
      let retData : any = data;
      this.products = retData.map( products =>  convertProduct( products));
      this.dataSource = new MatTableDataSource(this.products);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },error=>{
      alert("Product can not be deleted");
    });
  }
}

/** Builds and returns a new User. */
function convertProduct(product): Product {

  return {
    productCode: product.prodCode,
    productName: product.prodName,
    pid: product.pid
  };
}
