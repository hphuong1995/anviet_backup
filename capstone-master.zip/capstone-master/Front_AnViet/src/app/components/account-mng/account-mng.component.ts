import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import {Location} from '@angular/common';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';


export interface Company {
  shortName: string
  cid: string
}

@Component({
  selector: 'app-account-mng',
  templateUrl: './account-mng.component.html',
  styleUrls: ['./account-mng.component.css']
})
export class AccountMngComponent implements OnInit {
  currentUser: any = {};
  shortName: string;
  company : string[];
  email: string;
  phone: string;
  userForm: FormGroup;
  type: string;

  displayedColumns: string[] = ['companyName', 'action'];

  dataSource: MatTableDataSource<Company>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  companies: Company[];

  currentRelatedCompanies: any[] = [];


  constructor(  private data: DataService,
                private userService: UserService,
                private dataService: DataService,
                private formBuilder : FormBuilder,
                private route:ActivatedRoute,
                private _location: Location,
                private router: Router
              ) { }

  editForm: FormGroup;

  ngOnInit() {
    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }
    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    this.editForm = this.formBuilder.group({
      phone: ['', Validators.required],
      shortName: [''],
      type:['',Validators.required]
    });
    //this.currentUser = this.userService.getCurrentUser();
    this.dataService.getAccount(this.route.snapshot.params['uid']).subscribe (data=>{
      this.currentUser = data;
      this.currentRelatedCompanies = this.currentUser.companies;

      if(this.currentUser.email)
        this.email = this.currentUser.email;
      if(this.currentUser.phone)
        this.phone = this.currentUser.phone;
      if(this.currentUser.shortName)
        this.shortName = this.currentUser.shortName;
      if(this.currentUser.company)
        this.company = this.currentUser.company;
      if(this.currentUser.type)
        this.type = this.currentUser.type;

      this.editForm = this.formBuilder.group({
        phone: [this.phone, Validators.required],
        shortName: [this.shortName],
        type: [this.type]
      });

      this.dataService.getAllCompaniesByAdmOrMng().subscribe( data=>{
        let retData : any = data;

        if(this.currentUser.companies && this.currentUser.companies.length !== 0){
          retData = retData.filter( company =>{
            let flag = true;
            this.currentUser.companies.forEach( relatedCompany =>{
              if(relatedCompany.companyShortName === company.companyShortName){
                flag = false;
              }
            });
            return flag;
          });
        }

        this.companies = retData.map( company =>  convertUser( company));

        this.dataSource = new MatTableDataSource(this.companies);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
    });

  }

  get formControl() { return this.editForm.controls; }

  saveEditAccount(){
    let updatedInfo: any = {
      phone : this.formControl.phone.value,
      uid: this.currentUser.uid,
    };

    if(this.formControl.shortName){
      updatedInfo.shortName = this.formControl.shortName.value;
    }else if(this.userService.getCurrentUser().shortName !== null){
      updatedInfo.shortName = this.userService.getCurrentUser().shortName;
    }
    else{
      updatedInfo.shortName = "";
    }

    if(this.formControl.phone){
      updatedInfo.phone = this.formControl.phone.value;
    }else if(this.userService.getCurrentUser().phone !== null){
      updatedInfo.phone = this.userService.getCurrentUser().phone;
    }
    else{
      updatedInfo.phone = "";
    }

    if(this.formControl.type){
      updatedInfo.type = this.formControl.type.value;
    }else if(this.userService.getCurrentUser().type !== null){
      updatedInfo.type = this.userService.getCurrentUser().type;
    }
    else{
      updatedInfo.type = "0";
    }

    updatedInfo.email = this.currentUser.email;

    //updatedInfo.type = this.currentUser.type;
    this.dataService.editAccountInfoByMngOrAdmin(updatedInfo).subscribe( data =>{
      this.currentUser = data;
      this.ngOnInit();
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  addCompany(cid : string){
    this.dataService.addCompanyToAnAccountByAdm(this.currentUser.uid, cid).subscribe( data =>{
      this.ngOnInit();
    });
  }

  deleteCompany(cid : string){
    console.log(cid);
    this.dataService.deleteCompanyFromUserByAdm(this.currentUser.uid, cid).subscribe( data =>{
      this.ngOnInit();
    });
  }

}

function convertUser(company): Company {

  return {
    shortName: company.companyShortName,
    cid : company.cid
  };
}
