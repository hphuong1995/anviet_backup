import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

export interface Warehouse {
  wid: string
  warehouseName: string
  warehouseCode: string
  availableSpace: string
}


@Component({
  selector: 'app-warehouses',
  templateUrl: './warehouses.component.html',
  styleUrls: ['./warehouses.component.css']
})
export class WarehousesComponent implements OnInit {
  displayedColumns: string[] = ['warehouseCode','warehouseName'];

  dataSource: MatTableDataSource<Warehouse>;
  currentWarehouseInView : any = {};

  warehouses: Warehouse[] = [];
  createNewWarehouseForm: FormGroup;
  editWarehouseForm: FormGroup;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _location: Location,
              private dataService : DataService,
              private router: Router,
              private userService : UserService,
              private formBuilder : FormBuilder) {

    this.createNewWarehouseForm = this.formBuilder.group({
      warehouseName: ['',Validators.required],
      warehouseCode: ['',Validators.required],
      avaSpace:['',Validators.required]
    });

    this.editWarehouseForm = this.formBuilder.group({
      warehouseName: ['',Validators.required],
      warehouseCode: ['',Validators.required],
      avaSpace:['',Validators.required]
    });

  }


  ngOnInit() {
    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    this.dataService.getAllWareHousesByAdmOrMng().subscribe( data =>{
      let retData : any = data;
      this.warehouses = retData.map( warehouse =>  convertWarehouse( warehouse));
      this.dataSource = new MatTableDataSource(this.warehouses);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  get createFormControl() { return this.createNewWarehouseForm.controls; }
  get editFormControl() { return this.editWarehouseForm.controls; }


  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  viewWarehouse( wh){
    this.currentWarehouseInView = wh;
    console.log(  this.currentWarehouseInView);
    this.editWarehouseForm = this.formBuilder.group({
      warehouseName: [this.currentWarehouseInView.warehouseName,Validators.required],
      warehouseCode: [this.currentWarehouseInView.warehouseCode,Validators.required],
      avaSpace:[this.currentWarehouseInView.availableSpace,Validators.required]
    });
  }

  submitEditWarehouse(){
    if(this.editFormControl.warehouseName.value === ''){
      return;
    }
    if(this.editFormControl.warehouseCode.value === ''){
      return;
    }
    if(this.editFormControl.avaSpace.value === ''){
      return;
    }

    let updateObj : any = {
      wid : this.currentWarehouseInView.wid,
      warehouseName: this.editFormControl.warehouseName.value,
      warehouseCode: this.editFormControl.warehouseCode.value,
      availableSpace: this.editFormControl.avaSpace.value
    };

    this.dataService.updateWarehouse(updateObj).subscribe( data =>{
      let retData : any = data;
      this.warehouses = retData.map( warehouse =>  convertWarehouse( warehouse));
      this.dataSource = new MatTableDataSource(this.warehouses);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  createWarehouse(){
    let newWarehouseObj = {
      warehouseName: this.createFormControl.warehouseName.value,
      warehouseCode: this.createFormControl.warehouseCode.value,
      avaSpace: this.createFormControl.avaSpace.value,
    };

    this.dataService.createNewWarehouse(newWarehouseObj).subscribe( data =>{
      let retData : any = data;
      this.warehouses = retData.map( warehouse =>  convertWarehouse( warehouse));
      this.dataSource = new MatTableDataSource(this.warehouses);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.createFormControl.warehouseName.setValue('');
      this.createFormControl.warehouseCode.setValue('');
      this.createFormControl.avaSpace.setValue('');
    });
  }

  deleteWarehouse( wid: string){
    this.dataService.deteleWarehouse( wid).subscribe( data =>{
      let retData : any = data;
      this.warehouses = retData.map( warehouse =>  convertWarehouse( warehouse));
      this.dataSource = new MatTableDataSource(this.warehouses);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  checkCreate(){
    if(this.createFormControl.warehouseName.value === "" || this.createFormControl.warehouseCode.value ===""|| this.createFormControl.avaSpace.value ===""){
      return false;
    }
    if(this.checkWarehouseCode()){
      return false;
    }
      return true;
  }

  checkWarehouseCode(){
    let flag : boolean = false;
    this.warehouses.forEach( prod =>{
      if(prod.warehouseCode === this.createFormControl.warehouseCode.value){
        flag = true;
      }
    });
    return flag;
  }
}

/** Builds and returns a new User. */
function convertWarehouse(warehouse): Warehouse {

  return {
    wid: warehouse.wid,
    warehouseName: warehouse.warehouseName,
    warehouseCode: warehouse.warehouseCode,
    availableSpace: warehouse.avaSpace
  };
}
