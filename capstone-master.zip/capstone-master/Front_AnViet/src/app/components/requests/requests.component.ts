import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { UserService } from '../../services/user.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import uuid from 'uuid/v1';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatDatepicker} from '@angular/material/datepicker';
import {Moment} from 'moment';

export interface RequestData {
  rid : string
  shortName: string
  date: string
  message : string
  companyShortName: string
  status: string
}

import * as _moment from 'moment';


// See the Moment.js docs for the meaning of these formats:
// https://momentjs.com/docs/#/displaying/format/
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.css'],
  providers: [
   {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
   {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
 ],
})
export class RequestsComponent implements OnInit {

  constructor( private dataService : DataService,
               private userService : UserService,
               private _location: Location,
               private router : Router,
               private formBuilder : FormBuilder) { }

   currentProcessingCompanies: any;
   currentSelectedProcessingCompany:any;

   displayedColumns: string[] = ['sender','company', 'date', 'status'];
   dataSource: MatTableDataSource<RequestData>;
   requests: RequestData[];

   filterForm: FormGroup;
   createNewRequestForm: FormGroup;
   processRequestForm: FormGroup;

   check: string ="Hello";

   requestInView : any = {};
   customerList: any = [];
   currentCompanySet: any = [];
   currentCreatingItems: any = [];
   productList: any = [];
   unitList: any =[];
   inventoryList: any = [];
   warehouseList: any = [];

   selectedCompanyIdOnCreating: string = "";
   selectedCustomerIdOnCreating:string = "";

   createRequestPrivilegeCheck : boolean = false;
   missMatchCompany: boolean = false;

   filteredCustomerOptions: Observable<string[]>;
   filteredCompanyOptions: Observable<string[]>;

   missingInputForCreatingItem: boolean = false;
   emptyRequestItemList: boolean = false;

   addingActivityErrorCheck : boolean = false;
   addingActivityErrorMessage: string = "";

   importExportType: string = "Import";
   importExportActivityType: string = "Import";
   currentActivityWorkType: number = 0;

   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;

   filterSearchObj = {
     startDate: null,
     endDate: null,
     company: null,
     sender: null,
     status: null
   }

  ngOnInit() {
    this.currentProcessingCompanies = this.userService.getAllRelatedCompanies();
    this.currentSelectedProcessingCompany = this.userService.getSelectedCompany();

    this.processRequestForm = this.formBuilder.group({
      driver_plate: [''],
      message: [''],
      item_product: [''],
      activity_inventory: [''],
      activity_amount: [''],
      activity_warehouse:[''],
      activity_product: [''],
      activity_unit:[''],
      activity_expire_date: new FormControl(_moment())
    });

    this.filterForm = this.formBuilder.group({
      content: [''],
      sender: [''],
      status:['Pending'],
      mng_company:[''],
      company: [this.currentProcessingCompanies.companyShortName]
    });
    this.filterFormControl.company.setValue(this.currentProcessingCompanies.companyShortName);
    this.generateCreatingRequestControl();

    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    this.filteredCustomerOptions = this.createFormControl.sender.valueChanges
      .pipe(
        startWith(''),
        map( value  => this._filterCustomer(value))
      );

    this.filteredCompanyOptions = this.createFormControl.company.valueChanges
      .pipe(
        startWith(''),
        map( value  => this._filterCompany(value))
      );

    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      this.dataService.admOrMngGetAllAccountsForCreatingRequest().subscribe( data =>{
        let retData = data;
        this.customerList = retData;
        this.filterChange();
      });
    }
    else{
      this.filterChange();
    }
  }

/********************** FORM CONTROL *****************/

  get filterFormControl() { return this.filterForm.controls; }
  get createFormControl() { return this.createNewRequestForm.controls; }
  get processRequestControl() { return this.processRequestForm.controls;}

  generateCreatingRequestControl(){
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      this.createNewRequestForm = this.formBuilder.group({
        sender:[''],
        type: [''],
        company: [''],
        content: [''],
        itemType: [''],
        itemContent: [''],
        itemUnit: [''],
        itemAmount:[''],
        itemExpireDate: new FormControl(_moment()),
        product: ['']
      });
    }
    else if( this.userService.isCusAccount()){
      this.currentCompanySet = this.userService.getAllRelatedCompanies();
      this.selectedCustomerIdOnCreating = this.userService.getCurrentUser().uid;
      // console.log(this.currentCompanySet);
      if(this.currentCompanySet.length > 1){
        this.createNewRequestForm = this.formBuilder.group({
          sender:[{value : this.userService.getCurrentUser().shortName, disabled: true}],
          type: [''],
          company: [''],
          content: [''],
          itemType: [''],
          itemContent: [''],
          itemUnit: [''],
          itemAmount:[''],
          itemExpireDate:new FormControl(_moment()),
          product: ['']
        });
      }
      else{
        this.createNewRequestForm = this.formBuilder.group({
          sender:[{value : this.userService.getCurrentUser().shortName, disabled: true}],
          type: [''],
          company: [{value: this.userService.getSelectedCompany().companyShortName, disabled:true}],
          content: [''],
          itemType: [''],
          itemContent: [''],
          itemUnit: [''],
          itemAmount:[''],
          itemExpireDate:new FormControl(_moment()),
          product: ['']
        });
      }
    }
    else{
      this.createNewRequestForm = this.formBuilder.group({
        sender:[''],
        date: [{value : new Date().toString().substr(0,25), disabled: true}],
        type: [''],
        itemType: [''],
        itemContent: [''],
        itemUnit: [''],
        itemAmount:[''],
        itemExpireDate: new FormControl(_moment()),
        product: ['']
      });
    }
  }



/********************  END OF FORM CONTROL *****************/

validateRequestItemsAndActivities( items, activities){
  let cloneItemList = JSON.parse(JSON.stringify(items));
  let cloneActivityList = JSON.parse(JSON.stringify(activities));
  let flag = true;

  cloneActivityList.forEach( activity=>{
    activity.activity_amount = parseInt(activity.activity_amount);
    cloneItemList.forEach(item =>{
      item.item_amount = parseInt(item.item_amount);
      if(item.activity_type === activity.activity_type && item.item_product_pid === activity.inven_prod_pid
          && item.item_unit_uid === activity.inven_unit_uid && item.item_expire_date === activity.inven_expire_date){
        if(item.activity_type === "Export" && parseInt(activity.inven_amount) < activity.activity_amount ){
          flag = false;
          console.log("cant export more than what have in inven");
        }

        item.item_amount = item.item_amount - activity.activity_amount;
        activity.activity_amount = 0;

      }
    });
  });

  cloneItemList.forEach(item => {
    if(item.item_amount !== 0){
      flag = false;
    }
  });
  cloneActivityList.forEach(activity => {
    if(activity.activity_amount !== 0){
      flag = false;
    }
  });

  return flag;
}

/********************** PROCESS REQUEST *****************/
  approveRequest(rid : string){

    if(this.validateRequestItemsAndActivities(this.requestInView.items, this.requestInView.activities)){
      this.addingActivityErrorCheck = false;
      this.dataService.approveRequest(rid, this.requestInView).subscribe( data =>{
        let retData: any = data;
        if(retData.success === "true"){
          this.requestInView.status = "Approved";
        }
        else{
          this.addingActivityErrorCheck = true;
          this.addingActivityErrorMessage = "NOOOOO";
        }
        this.filterChange();
      });
    }
    else{
      this.addingActivityErrorCheck = true;
      this.addingActivityErrorMessage = "Request items list is not match with activities";
      return;
    }
  }

  isValid() {
    return this.validateRequestItemsAndActivities( this.requestInView.items, this.requestInView.activities );
  }

  validateRequest( rid : string ){
    if(this.processRequestControl.driver_plate.value === ''){
      this.addingActivityErrorCheck = true;
      this.addingActivityErrorMessage = "Please specify Driver plate";
      return;
    }
    else{
      this.addingActivityErrorCheck = false;
      this.addingActivityErrorMessage = "";
      this.requestInView.driver_plate = this.processRequestControl.driver_plate.value;
    }

    this.dataService.validateRequest( rid).subscribe(data =>{
      this.filterChange();
    });
  }

  denyRequest(rid : string){
    this.dataService.denyRequest(rid, this.processRequestControl.message.value).subscribe( data =>{
      this.processRequestControl.message.setValue("");
      this.filterChange();
    });
  }

  cancelRequest(rid : string){
    this.dataService.cancelRequestByCustomer(rid).subscribe( data =>{
      this.filterChange();
    });
  }

  denyCancelation( rid: string){
    this.dataService.denyCancelationByMngOrAdm(rid, this.processRequestControl.message.value).subscribe( data =>{
      this.processRequestControl.message.setValue("");
      this.filterChange();
    });
  }

  approveCancelation( rid : string){
    this.dataService.approveCancelationByMngOrAdm(rid).subscribe( data =>{
      this.filterChange();
    });
  }

/********************  END OF PROCESS REQUEST *****************/

/********************** FILTER REQUEST *****************/

  startDateChange(type: string, event: MatDatepickerInputEvent<Date>): void {
    this.filterSearchObj.startDate = event.value;
    this.filterChange();
  }

  endDateChange(type: string, event: MatDatepickerInputEvent<Date>): void {
    this.filterSearchObj.endDate = event.value;
    this.filterChange();
  }

  filterChange(){
    if(this.filterFormControl.sender.value !== '' || this.filterFormControl.sender.value !== this.filterSearchObj.sender ){
      this.filterSearchObj.sender = this.filterFormControl.sender.value.trim();
    }
    if(this.filterFormControl.mng_company.value !== '' || this.filterFormControl.mng_company.value !== this.filterSearchObj.company){
      this.filterSearchObj.company = this.filterFormControl.mng_company.value.trim();
    }
    if(this.filterFormControl.status.value !== '' || this.filterFormControl.status.value !== this.filterSearchObj.status){
      this.filterSearchObj.status = this.filterFormControl.status.value.trim();
    }

    if(this.filterFormControl.status.value === ''){
      this.filterSearchObj.status = null;
    }
    this.generateTableData(this.filterSearchObj);
  }

  generateTableData( filterSearchObj){
    if(this.userService.getCurrentUser().type === '1' || this.userService.getCurrentUser().type === '2'){
      this.dataService.getAllRequestsByAdm( filterSearchObj ).subscribe( data =>{
        let retData : any = data;
        this.requests = retData.map( request =>  convertRequests( request));
        this.dataSource = new MatTableDataSource(this.requests);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

        this.dataService.getAllProdsByAdmOrMng().subscribe( data =>{
          //console.log(data);
          this.productList = data;
          this.getUnitListAndWarehouseListFromServer();
        });
        // GET UNIT LIST
      });
    }
    else if(this.userService.getCurrentUser().type === '0'){
      this.dataService.getAllRequestsByCus( this.userService.getCurrentUser().uid, filterSearchObj ).subscribe( data =>{
        let retData : any = data;
        this.requests = retData.map( request =>  convertRequests( request));
        this.dataSource = new MatTableDataSource(this.requests);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.getUnitListAndWarehouseListFromServer();
      });
    }
  }

  getUnitListAndWarehouseListFromServer(){
    this.dataService.getUnitListFromServer().subscribe( units =>{
      this.unitList = units;
      if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
        this.dataService.getAllWareHousesByAdmOrMng().subscribe(warehouses =>{
          this.warehouseList = warehouses;
        });
      }
    });
  }

  setCurrentCompany(companyShortName){
    this.userService.setCurrentCompanyOnChange(this.filterFormControl.company.value);
    this.filterChange();
  }

  setProductForRequestItem( item , product){
    //console.log(item.item_iid, product.pid);
    this.dataService.setProductForRequestItem( item.item_iid, product.pid, this.requestInView.rid).subscribe( data =>{
      console.log( this.requestInView);
      this.requestInView.items = data;
      this.requestInView.items.forEach( item =>{
        this.productList.forEach( product =>{
          if(item.item_product_pid === product.pid){
            item.product_name = product.prodName;
          }
        });
      });
    });
  }

  /********************  END OF FILTER REQUEST *****************/

  /********************** VIEW REQUEST *****************/

  viewRequest(request){
    this.dataService.getOneRequest( request.rid ).subscribe( data =>{
      let retData : any = data;
      //console.log(request.message);
      this.processRequestControl.activity_inventory.setValue('');
      this.processRequestControl.activity_amount.setValue('');
      this.processRequestControl.activity_warehouse.setValue('');
      this.processRequestControl.activity_unit.setValue('');

      //this.processRequestControl.activity_expire_date.setValue(new FormControl(_moment()));


      this.requestInView = retData;
      console.log(this.requestInView);
      this.requestInView.date = this.requestInView.date.substr(0,25);
      this.requestInView.items.forEach( item =>{
        this.productList.forEach( product =>{
          if(item.item_product_pid === product.pid){
            item.product_name = product.prodName;
          }
        });

        this.unitList.forEach ( unit =>{
          if( item.item_unit_uid === unit.unit_uid){
            item.unit_name = unit.unit_name;
          }
        })
      });
    });
  }

  updateInventoryList(){
    console.log(this.requestInView);
    this.dataService.getAllInventoriesByAdm( {cid : this.requestInView.company_id}).subscribe( data =>{
      this.inventoryList = data;
    });
  }

  /********************  END OF VIEW REQUEST *****************/

  /********************** CREATE REQUEST *****************/

  chosenYearHandler(normalizedYear: Moment) {
    //console.log(this.createFormControl.itemExpireDate.value);

    const ctrlValue = this.createFormControl.itemExpireDate.value;
    ctrlValue.year(normalizedYear.year());
    this.createFormControl.itemExpireDate.setValue(ctrlValue);
  }

  chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.createFormControl.itemExpireDate.value;
    ctrlValue.month(normalizedMonth.month());
    this.createFormControl.itemExpireDate.setValue(ctrlValue);
    datepicker.close();
  }

  chosenYearForActivityHandler(normalizedYear: Moment) {
    //console.log(this.processRequestControl.activity_expire_date.value);
    const ctrlValue = this.processRequestControl.activity_expire_date.value;
    ctrlValue.year(normalizedYear.year());
    this.processRequestControl.activity_expire_date.setValue(ctrlValue);
  }

  chosenMonthForActivityHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.processRequestControl.activity_expire_date.value;
    ctrlValue.month(normalizedMonth.month());
    this.processRequestControl.activity_expire_date.setValue(ctrlValue);
    datepicker.close();
  }

  private _filterCustomer(value): string[] {
    const filterValue = value.toLowerCase();
    //console.log(this.customerList.filter(customer => customer.shortName.toLowerCase().includes(filterValue)));
    return this.customerList.filter(customer => customer.shortName.toLowerCase().includes(filterValue));
  }

  private _filterCompany(value): string[] {
    const filterValue = value.toLowerCase();
    //console.log(this.customerList.filter(customer => customer.shortName.toLowerCase().includes(filterValue)));
    return this.currentCompanySet.filter(company => company.companyShortName.toLowerCase().includes(filterValue));
  }

  addRequestItem(){
    if( this.createFormControl.itemContent.value === "" || this.createFormControl.itemAmount.value === "" || this.createFormControl.itemUnit.value === ""){
      this.missingInputForCreatingItem = true;
      return;
    }
    else{
      this.missingInputForCreatingItem = false;
    }
    let currentItemUnit: any = {};
    this.unitList.forEach(unit =>{
      if(unit.unit_uid === parseInt(this.createFormControl.itemUnit.value, 10)){
        currentItemUnit = unit;
      }
    });

    this.currentCreatingItems.push({iid: uuid(),
                                    type: this.importExportType,
                                    content: this.createFormControl.itemContent.value,
                                    amount: this.createFormControl.itemAmount.value,
                                    unit: currentItemUnit,
                                    item_expire_date: this.createFormControl.itemExpireDate.value.format('MM/YYYY')
                                  });
    if(this.currentCreatingItems.length !== 0){
      this.createRequestPrivilegeCheck = true;
    }
    this.createFormControl.itemContent.setValue("");
    this.createFormControl.itemType.setValue("");
    this.createFormControl.itemAmount.setValue("");
    this.createFormControl.itemUnit.setValue("");
    this.createFormControl.product.setValue("");
    //this.createFormControl.itemExpireDate.setValue());
  }

  addActivity(){
    if(!this.checkAllItemsHaveProduct()){
      this.addingActivityErrorCheck = true;
      this.addingActivityErrorMessage = "Please specify all products for request items";
      return;
    }
    if(this.processRequestControl.activity_amount.value === ""){
      this.addingActivityErrorCheck = true;
      this.addingActivityErrorMessage = "Please specify all amount for activity";
      return;
    }
    let newActivityObj: any = {
      activity_mng_uid : this.userService.getCurrentUser().uid,
      activity_request_rid: this.requestInView.rid,
      activity_date : new Date().toString(),
      activity_type: this.importExportActivityType,
      activity_status: "Processing",
      activity_amount : this.processRequestControl.activity_amount.value,
      activity_work_type: this.currentActivityWorkType
    }

    if(newActivityObj.activity_type === "Export" && this.processRequestControl.activity_inventory.value === ""){
      this.addingActivityErrorCheck = true;
      this.addingActivityErrorMessage = "All Export activity must have a corresponding Inventory";
      return;
    }

    if(this.processRequestControl.activity_inventory.value === ""){
      if(this.processRequestControl.activity_product.value === "" || this.processRequestControl.activity_unit.value === ""
      || this.processRequestControl.activity_expire_date.value === "" || this.processRequestControl.activity_warehouse.value === ""){
        this.addingActivityErrorCheck = true;
        this.addingActivityErrorMessage = "Please specify product, product expire date, unit and warehouse to make a new Inventory";
        return;
      }
    }

    if(this.processRequestControl.activity_warehouse.value !== ""){
      newActivityObj.activity_newInven_warehouse = this.processRequestControl.activity_warehouse.value;
      newActivityObj.activity_newInven_unit = this.processRequestControl.activity_unit.value;
      newActivityObj.activity_newInven_expireDate = this.processRequestControl.activity_expire_date.value.format('MM/YYYY');
      newActivityObj.activity_newInven_product = this.processRequestControl.activity_product.value;
      newActivityObj.activity_company_cid = this.requestInView.company_id;
    }
    else{
      newActivityObj.activity_inven_iid = this.processRequestControl.activity_inventory.value;
    }

    this.dataService.createNewActivityForRequest(newActivityObj).subscribe( data =>{
      console.log(data);
      this.requestInView.activities = data;
      this.addingActivityErrorCheck = false;
      this.processRequestControl.activity_inventory.setValue('');
      this.processRequestControl.activity_amount.setValue('');
      this.processRequestControl.activity_warehouse.setValue('');
      this.processRequestControl.activity_unit.setValue('');
    });
  }

  deleteActivity(activityObj){
    this.dataService.deleteActivityByAdmOrMng(activityObj).subscribe( activities =>{
      this.requestInView.activities = activities;
    });
  }

  showSelectWareHouseOnAddingActivity(){
    if(this.importExportActivityType === "Import" && this.processRequestControl.activity_inventory.value === ""){
      return true;
    }
    return false;
  }

  checkAllItemsHaveProduct(){
    let flag = true;
    this.requestInView.items.forEach (item =>{
      if(!item.item_product_pid){
        flag = false;
      }
    });
    return flag;
  }

  selectImportExport( value ){
    this.importExportType = value;
    //console.log(this.importExportType);
  }

  selectImportExportForNewActivity( value){
    this.importExportActivityType = value;
  }

  selectActivityWorkType( value){
    this.currentActivityWorkType = parseInt(value);
  }

  setSelectedCompany(company : any){
    if(this.userService.isCusAccount()){
      this.selectedCompanyIdOnCreating = company.company_cid;
      let flag = false;
      //console.log(this.userService.getAllRelatedCompanies());
      this.userService.getAllRelatedCompanies().forEach( company =>{
        if(company.company_cid === this.selectedCompanyIdOnCreating && company.sendRequest === '1'){
          flag = true;
        }
      });
      this.createRequestPrivilegeCheck = flag;
    }
    else{
      this.selectedCompanyIdOnCreating = company.cid;
      this.dataService.getPrivilegeByUserAndCompany( company.cid, this.selectedCustomerIdOnCreating).subscribe( data =>{
        let retData : any = data;
        if(retData[0].sendRequest === '1'){
          this.missMatchCompany = false;
          if(this.currentCreatingItems.length === 0){
            this.createRequestPrivilegeCheck = false;
          }
          else{
            this.createRequestPrivilegeCheck = true;
          }
        }
        else{
          this.createRequestPrivilegeCheck = false;
          this.missMatchCompany = true;
        }

      });
    }
  }

  setSelectedCustomer(customerUid: string){
    this.selectedCustomerIdOnCreating = customerUid;
    this.updateCurrentCompanySet();
  }

  updateCurrentCompanySet(){
    this.dataService.getAllRelatedCompaniesOfAnUserByAdmOrMng(this.selectedCustomerIdOnCreating).subscribe( data =>{
      this.currentCompanySet = data;
      this.filteredCompanyOptions = this.createFormControl.company.valueChanges
        .pipe(
          startWith(''),
          map( value  => this._filterCompany(value))
        );
    });
  }

  deleteRequestItem(item_iid: string){
    this.currentCreatingItems = this.currentCreatingItems.filter( item => item_iid !== item.iid);
  }

  createRequest(){
    let requestToCreateObj = {
      user_uid : this.selectedCustomerIdOnCreating,
      company_cid: this.selectedCompanyIdOnCreating,
      date: new Date().toString(),
      items: this.currentCreatingItems,
      status: "Pending"
    }
    if(requestToCreateObj.items.length === 0){
      this.emptyRequestItemList = true;
      return;
    }
    this.emptyRequestItemList = false;
    this.dataService.createNewRequest(requestToCreateObj).subscribe( data =>{
      console.log(data);
      this.filterChange();
      this.resetCreatingObject();
    });
  }

  resetCreatingObject(){
    this.currentCompanySet = [];
    this.currentCreatingItems = [];
    this.selectedCompanyIdOnCreating = "";
    this.createRequestPrivilegeCheck = false;

    if(this.userService.isCusAccount()){
      this.selectedCustomerIdOnCreating = this.userService.getCurrentUser().uid;
    }
    else{
      this.selectedCustomerIdOnCreating = "";
    }


    this.generateCreatingRequestControl();
    this.filteredCustomerOptions = this.createFormControl.sender.valueChanges
      .pipe(
        startWith(''),
        map( value  => this._filterCustomer(value))
      );

    this.filteredCompanyOptions = this.createFormControl.company.valueChanges
      .pipe(
        startWith(''),
        map( value  => this._filterCompany(value))
      );
  }

  validateButtonAppear(){
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      if(this.requestInView.status === "Approved"){
        return true;
      }
    }
    else{
      return false;
    }
  }

  approveButtonAppear(){
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      if(this.requestInView.status === "Pending"){
        return true;
      }
    }
    else{
      return false;
    }
  }

  denyButtonAppear(){
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      if(this.requestInView.status === "Pending"){
        return true;
      }
    }
    else{
      return false;
    }
  }

  cancelButtonAppear(){
    if(this.userService.isCusAccount()){
      if(this.requestInView.status === "Pending" || this.requestInView.status === "Approved"){
        return true;
      }
    }
    else{
      return false;
    }
  }

  denyCancelationButtonAppear(){
    //console.log(this.requestInView.status);
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      if(this.requestInView.status === "Cancel Pending"){
        return true;
      }
    }
    else{
      return false;
    }
  }

  /********************  END OF CREATE REQUEST *****************/
}

/** Builds and returns a new User. */
function convertRequests(request): RequestData {
  return {
    rid : request.rid,
    shortName: request.shortName,
    date: request.date.substr(3,12),
    message: request.message,
    companyShortName: request.companyShortName,
    status: request.status,
  };
}
