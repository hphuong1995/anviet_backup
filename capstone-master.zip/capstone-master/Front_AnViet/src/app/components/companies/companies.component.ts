import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

export interface Company {
  companyName: string
  cid: string
}

@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.css']
})
export class CompaniesComponent implements OnInit {
  displayedColumns: string[] = ['companyName', 'action'];

  dataSource: MatTableDataSource<Company>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  companies: Company[];
  createCompanyForm: FormGroup;

  constructor(private _location: Location,
              private dataService : DataService,
              private router: Router,
              private userService : UserService,
              private formBuilder : FormBuilder) { }



  ngOnInit() {
    this.createCompanyForm = this.formBuilder.group({
      companyName: ['',Validators.required],
      companyShortName: ['',Validators.required],
      email:['',Validators.required],
      phone: ['',Validators.required],
      address: ['',Validators.required],
      taxCode:['',Validators.required],
      portFee: ['',Validators.required],
      storageFee:['',Validators.required],
    });

    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      this.router.navigate(['account']);
      return;
    }

    this.dataService.getAllCompaniesByAdmOrMng().subscribe( data =>{
      let retData : any = data;
      this.companies = retData.map( company =>  convertUser( company));
      this.dataSource = new MatTableDataSource(this.companies);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  get createFormControl() { return this.createCompanyForm.controls; }

  createCompany(){
    let newCompany = {
      companyName: this.createFormControl.companyName.value,
      companyShortName: this.createFormControl.companyShortName.value,
      email: this.createFormControl.email.value,
      phone: this.createFormControl.phone.value,
      address: this.createFormControl.address.value,
      taxCode:this.createFormControl.taxCode.value,
      portFee: this.createFormControl.portFee.value,
      storageFee:this.createFormControl.storageFee.value,
    };

    this.dataService.createNewCompany(newCompany).subscribe( data =>{
      let retData : any = data;
      this.companies = retData.map( company =>  convertUser( company));
      this.dataSource = new MatTableDataSource(this.companies);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.createFormControl.companyName.setValue('');
      this.createFormControl.companyShortName.setValue('');
      this.createFormControl.email.setValue('');
      this.createFormControl.phone.setValue('');
      this.createFormControl.address.setValue('');
      this.createFormControl.taxCode.setValue('');
      this.createFormControl.portFee.setValue('');
      this.createFormControl.storageFee.setValue('');
    });
  }

  checkCreate(){
    if(this.createFormControl.companyName.value === "" || this.createFormControl.companyShortName.value ==="" ||
        this.createFormControl.email.value === "" || this.createFormControl.phone.value === "" || this.createFormControl.address.value === "" ||
        this.createFormControl.taxCode.value === "" || this.createFormControl.portFee.value === "" || this.createFormControl.storageFee.value ===""){
          return false;
        }
      return true;
  }
}




/** Builds and returns a new User. */
function convertUser(company): Company {
  return {
    companyName: company.companyName,
    cid : company.cid
  };
}
