import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  currentUser: any;
  userCode: string;
  shortName: string;
  company : string;
  email: string;
  phone: string;
  storageFee: string;
  portFee: string;

  constructor(  private data: DataService,
                private userService: UserService,
                private dataService: DataService,
                private formBuilder : FormBuilder,
                private _location: Location,
                private router: Router

              ) { }

  editForm: FormGroup;

  ngOnInit() {
    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }


    this.currentUser = this.userService.getCurrentUser();
    if(this.currentUser.phone)
      this.phone = this.currentUser.phone;
    if(this.currentUser.shortName)
      this.shortName = this.currentUser.shortName;

    this.editForm = this.formBuilder.group({
      phone: [this.phone, Validators.required],
      shortName: [this.shortName]
    });
  }

  get formControl() { return this.editForm.controls; }

  saveEditAccount(){
    let updatedInfo: any = {
      phone : this.formControl.phone.value,
      uid: this.userService.getCurrentUser().uid,
    };

    if(this.formControl.shortName){
      updatedInfo.shortName = this.formControl.shortName.value;
    }else if(this.userService.getCurrentUser().shortName !== null){
      updatedInfo.shortName = this.userService.getCurrentUser().shortName;
    }
    else{
      updatedInfo.shortName = "";
    }

    updatedInfo.email = this.userService.getCurrentUser().email;
    updatedInfo.type = this.userService.getCurrentUser().type;

    this.dataService.editAccountInfo(updatedInfo).subscribe( data =>{
      var retData : any;
      retData = data;
      if(!retData.err){
        localStorage.setItem('user', JSON.stringify(updatedInfo));
      }
      this.ngOnInit();
    });
  }


}
