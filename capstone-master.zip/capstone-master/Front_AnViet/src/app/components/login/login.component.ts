import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  invalidUserNameOrPassword: false;
  errorCheck: boolean;
  errorMessage: string;
  constructor(  private formBuilder : FormBuilder,
                private userService : UserService,
                private router: Router,
              ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });

    if(this.userService.isAuthenticated()){
      this.router.navigate(['account']);
      return;
    }

    this.invalidUserNameOrPassword = false;
    this.userService.logout();
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }

      this.loading = true;
      this.userService.login(this.f.email.value, this.f.password.value).subscribe( data =>{
        var retData :any = data;
        if(retData.uid){
          var user = data;
          this.loading = false;
          localStorage.setItem('user', JSON.stringify(user));
          if(this.userService.getCurrentUser().companies && this.userService.getCurrentUser().companies.length !== 0){
            this.userService.setSelectedCompany(this.userService.getCurrentUser().companies[0]);
          }
          this.errorCheck = false;
          this.errorMessage = "";
          this.router.navigate(['account']);
        }
        else{
        }
      },error => {
        this.errorCheck = true;
        this.errorMessage = "Username or password is invalid";
      });
  }
}
