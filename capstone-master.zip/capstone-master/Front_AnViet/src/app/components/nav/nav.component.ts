import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import {Location} from '@angular/common';


@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  currentUser :Object;
  currentCompanies: any;
  currentSelectedCompany:any;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.currentUser = this.userService.getCurrentUser();
  }

  checkValidUser(){
    if(!this.userService.isAuthenticated()){
      return false;
    }
    if(!this.userService.isAdmAccount() && !this.userService.isMngAccount()){
      if(this.userService.getAllRelatedCompanies().length === 0){
        return false;
      }
    }
    return true;
  }
}
