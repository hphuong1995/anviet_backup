import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { UserService } from '../../services/user.service';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

export interface Inventory {
  company: string
  warehouse: string
  product: string
  amount: string,
  expire_date: string
}

@Component({
  selector: 'app-inventories',
  templateUrl: './inventories.component.html',
  styleUrls: ['./inventories.component.css']
})
export class InventoriesComponent implements OnInit {

  constructor( private dataService : DataService,
               private userService : UserService,
               private _location: Location,
               private router : Router,
               private formBuilder : FormBuilder) { }

  currentProcessingCompanies: any;
  currentSelectedProcessingCompany:any;


  displayedColumns: string[] = ['company','warehouse', 'product', 'expire_date', 'amount'];
  dataSource: MatTableDataSource<Inventory>;
  inventories: Inventory[];
  filterForm: FormGroup;

  unitList: any =[];


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  filterSearchObj = {
    warehouse_name: null,
    product_name: null,
    company_name: null,
  }

  ngOnInit() {
    this.currentProcessingCompanies = this.userService.getAllRelatedCompanies();
    this.currentSelectedProcessingCompany = this.userService.getSelectedCompany();

    this.filterForm = this.formBuilder.group({
      warehouse: [''],
      product: [''],
      company: [''],
      companyCustomer: ['']
    });

    this.filterFormControl.company.setValue(this.currentProcessingCompanies.companyShortName);


    if(!this.userService.isAuthenticated()){
      this.router.navigate(['login']);
      return;
    }

    this.filterChange();

  }

  filterChange(){
    if(this.filterFormControl.warehouse.value !== '' || this.filterFormControl.warehouse.value !== this.filterSearchObj.warehouse_name){
      this.filterSearchObj.warehouse_name = this.filterFormControl.warehouse.value.trim();
    }
    if(this.filterFormControl.product.value !== '' || this.filterFormControl.product.value !== this.filterSearchObj.product_name){
      this.filterSearchObj.product_name = this.filterFormControl.product.value.trim();
    }
    if(this.filterFormControl.company.value && this.filterFormControl.company.value !== this.filterSearchObj.company_name){
      this.filterSearchObj.company_name = this.filterFormControl.company.value.trim();
    }
    this.generateTableData(this.filterSearchObj);
  }

  generateTableData( filterSearchObj){
    if(this.userService.getCurrentUser().type === '1' || this.userService.getCurrentUser().type === '2'){
      this.dataService.getAllInventoriesByAdm( filterSearchObj ).subscribe( data =>{
        let retData : any = data;
        this.inventories = retData.map( request =>  convertInventory( request));
        this.dataSource = new MatTableDataSource(this.inventories);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

        // GET UNIT LIST
        this.getUnitListFromServer();
      });
    }
    else if(this.userService.getCurrentUser().type === '0'){
      this.dataService.getAllInventoriesByCus( this.userService.getCurrentUser().uid, filterSearchObj ).subscribe( data =>{
        let retData : any = data;
        this.inventories = retData.map( request =>  convertInventory( request));
        this.dataSource = new MatTableDataSource(this.inventories);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.getUnitListFromServer();
      });
    }
  }

  setCurrentCompany(companyShortName){
    this.userService.setCurrentCompanyOnChange(this.filterFormControl.companyCustomer.value);
    this.filterChange();

  }

  getUnitListFromServer(){
    this.dataService.getUnitListFromServer().subscribe( data =>{
      this.unitList = data;
    });
  }

  viewInventory(){

  }

  get filterFormControl() { return this.filterForm.controls; }
}


/** Builds and returns a new User. */
function convertInventory(inventory): Inventory {
  return {
    company: inventory.companyShortName,
    product: inventory.prodName ,
    warehouse: inventory.warehouseName,
    amount: inventory.inven_amount + " " + inventory.unit_name,
    expire_date: inventory.inven_expire_date
  };
}
