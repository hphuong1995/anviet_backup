import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../services/user.service';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor( private http: HttpClient,
               private userService: UserService
              ) { }

  admGetAllRequests(){
    return this.http.get('api/v1/requests');
  }

  userCodeValidate(){
    return false;
  }

  editAccountInfo(updatedInfo : any){
    return this.http.put('api/v1/accounts/' + updatedInfo.uid , updatedInfo);
  }

  getAccount(accountId:string){
    return this.http.get('api/v1/admin/accounts/' + accountId);
  }

  admOrMngGetAllAccounts(){
    if(this.userService.getCurrentUser().type === '2'){
      return this.http.get('api/v1/admin/accounts');
    }
    else if (this.userService.getCurrentUser().type === '1'){
      return this.http.get('api/v1/manager/accounts');
    }
  }

  getAllRequestsByAdm( filterSearchObj : any ){
    let filterQuery = this.generateFilterQuery(filterSearchObj );
    return this.http.get('api/v1/manager/requests' + filterQuery);
  }

  getAllRequestsByCus(userId : string, filterSearchObj: any){
    filterSearchObj.uid = userId;
    filterSearchObj.cid = this.userService.getSelectedCompany().company_cid;
    let filterQuery = this.generateFilterQuery(filterSearchObj );
    return this.http.get('api/v1/requests' + filterQuery);
  }

  approveRequest( rid : string, reqObj:any){
    reqObj.updatingStatus = 'Approved';
    return this.http.put('api/v1/manager/requests/' + rid , reqObj);
  }

  denyRequest( rid : string, message : string ){
    return this.http.put('api/v1/manager/requests/' + rid , {updatingStatus : 'Denied', message: message});
  }

  cancelRequestByCustomer( rid: string){
    return this.http.put('api/v1/requests/' + rid , { updatingStatus: 'Canceling'})
  }

  denyCancelationByMngOrAdm( rid: string, message: string){
    return this.http.put('api/v1/manager/requests/' + rid , { updatingStatus: 'Deny Cancel' , message: message})

  }

  approveCancelationByMngOrAdm( rid: string){
    return this.http.put('api/v1/manager/requests/' + rid , { updatingStatus: 'Approve Cancel'})
  }

  validateRequest( rid : string){
    return this.http.put('api/v1/manager/requests/' + rid , { updatingStatus: 'Validated'})
  }

  getAllProdsByAdmOrMng(){
    return this.http.get('api/v1/manager/products');
  }

  getAllWareHousesByAdmOrMng(){
    return this.http.get('api/v1/manager/warehouses');
  }

  getAllCompaniesByAdmOrMng(){
    if(this.userService.isAdmAccount()){
      return this.http.get('api/v1/admin/companies');
    }
    else{
      return this.http.get('api/v1/manager/companies');
    }
  }

  getAllCompaniesByCus(){
    return this.http.get('api/v1/manager/companies?userId=' + this.userService.getCurrentUser().uid);
  }

  getACompanyByMng(cid : string){
    return this.http.get('api/v1/manager/companies/' + cid);
  }

  getACompanyByAdm(cid : string){
    return this.http.get('api/v1/admin/companies/' + cid);
  }

  getACompanyByCus(cid : string){
    return this.http.get('api/v1/companies/' + cid);
  }

  admGetAllEmployeesOfCompany( cid: string){
    return this.http.get('api/v1/admin/companies/' + cid + "/employees");
  }

  editAccountInfoByMngOrAdmin(updatedInfo : any){
    return this.http.put('api/v1/manager/accounts/' + updatedInfo.uid , updatedInfo);
  }

  editCompanyInfoByAdmin(updatedInfo: any){
    return this.http.put('api/v1/admin/companies/' + updatedInfo.cid, updatedInfo);
  }

  addCompanyToAnAccountByAdm( userId: string, companyId : string){
    return this.http.post('api/v1/admin/accounts/' + userId, {cid : companyId});
  }

  deleteCompanyFromUserByAdm( userId: string, companyId : string){
    return this.http.delete('api/v1/admin/accounts/' + userId + "?cid=" + companyId );
  }

  getOneRequest( requestId : string){
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      return this.http.get('api/v1/manager/requests/' + requestId);
    }
    else if( this.userService.isCusAccount()){
      return this.http.get('api/v1/requests/' + requestId + "?" + this.userService.getCurrentUser().uid);
    }
    else{
      return null;
    }
  }

  admOrMngGetAllAccountsForCreatingRequest(){
    return this.http.get('api/v1/manager/accounts');
  }

  getAllRelatedCompaniesOfAnUserByAdmOrMng(customerUid : string){
    return this.http.get('api/v1/manager/companies?uid=' + customerUid);
  }

  createNewRequest( newRequestObj: any){
    if(this.userService.isAdmAccount() || this.userService.isMngAccount()){
      return this.http.post('api/v1/manager/requests', newRequestObj);
    }
    else{
      newRequestObj.cid = this.userService.getSelectedCompany().company_cid;
      return this.http.post('api/v1/requests', newRequestObj);
    }
  }

  getUnitListFromServer(){
    return this.http.get('api/v1/units');
  }

  getAllInventoriesByAdm(filteredObject : any){
    let query = this.generateInventoryQuery(filteredObject);
    return this.http.get('api/v1/manager/inventories' + query);
  }

  getAllInventoriesByCus( customerId: string, filteredObject: any){
    filteredObject.uid = customerId;
    filteredObject.cid = this.userService.getSelectedCompany().company_cid;
    let query = this.generateInventoryQuery(filteredObject);

    return this.http.get('api/v1/inventories' + query);
  }

  updateCustomerRight( cid : string, uid: string, reqObj : any){
    return this.http.put('api/v1/admin/companies/' + cid + "/employees/" + uid, reqObj);
  }

  getPrivilegeByUserAndCompany( cid : string, uid: string){
    return this.http.get('api/v1/manager/companies/' + cid + "/employees/" + uid);
  }

  // NOT USED
  getAllProductOfACompany(cid :string ){
    return this.http.get('api/v1/manager/companies/' + cid + '/products');
  }

  setProductForRequestItem( item_iid, product_pid, request_rid){
    return this.http.put('api/v1/manager/request_items/' + item_iid , { product_pid : product_pid, request_rid : request_rid});
  }

  createNewActivityForRequest( newActivityObj : any ){
    return this.http.post('api/v1/manager/activities', newActivityObj);
  }

  deleteActivityByAdmOrMng( activityObj : any){
    console.log(activityObj);
    return this.http.delete('api/v1/manager/activities/' + activityObj.aid + "?activity_inven_iid=" + activityObj.activity_inven_iid + "&activity_inven_amount=" + activityObj.inven_amount + "&activity_request_rid=" + activityObj.activity_request_rid);
  }
  getAllActivitiesByAdmMng( filteredObject: any){
    return this.http.get('api/v1/manager/activities' + this.generateActivityFilterQuery(filteredObject));
  }

  createNewWarehouse(newWarehouseObj: any){
    return this.http.post('api/v1/admin/warehouses', newWarehouseObj);
  }

  createProduct(newProductObj:any){
    return this.http.post('api/v1/manager/products', newProductObj);
  }

  generateBillByAdmOrCus(billObj: any){
    return this.http.get('api/v1/bills?company=' + billObj.company + '&startDate=' + billObj.startDate + '&endDate=' + billObj.endDate);
  }

  updateWarehouse( updateObj : any){
    return this.http.put('api/v1/admin/warehouses/' + updateObj.wid, updateObj);
  }

  deteleWarehouse( wid :string){
    return this.http.delete('api/v1/admin/warehouses/' + wid);
  }

  updateProduct( updateObj : any){
    return this.http.put('api/v1/admin/products/' + updateObj.pid, updateObj);
  }

  createNewCompany( companyObj : any ){
    return this.http.post('api/v1/admin/company', companyObj);
  }

  deleteProduct( pid :string){
    return this.http.delete('api/v1/manager/products/'+ pid);
  }

// HELPER METHOD

generateActivityFilterQuery(filterSearchObj : any){
    var returnQueryString = "?";

    if(filterSearchObj.activity_company){
      returnQueryString = returnQueryString + "company=" + filterSearchObj.activity_company + "&";
    }

    if(filterSearchObj.startDate){
      returnQueryString = returnQueryString + "startDate=" + filterSearchObj.startDate.toString() + "&";
    }

    if(filterSearchObj.endDate){
      returnQueryString = returnQueryString + "endDate=" + filterSearchObj.endDate.toString() + "&";
    }

    if(filterSearchObj.activity_type){
      returnQueryString = returnQueryString + "type=" + filterSearchObj.activity_type + "&";
    }

    if(filterSearchObj.activity_status){
      returnQueryString = returnQueryString + "status=" + filterSearchObj.activity_status + "&";
    }

    if(filterSearchObj.activity_warehouse){
      returnQueryString = returnQueryString + "warehouse=" + filterSearchObj.activity_warehouse + "&";
    }
    if(filterSearchObj.activity_product){
      returnQueryString = returnQueryString + "product=" + filterSearchObj.activity_product + "&";
    }
    if(filterSearchObj.activity_code){
      returnQueryString = returnQueryString + "code=" + filterSearchObj.activity_code + "&";
    }

    if(returnQueryString[returnQueryString.length -1] === '&'){
      returnQueryString = returnQueryString.substr(0, returnQueryString.length -1);
    }
    return returnQueryString;
  }

  generateInventoryQuery(filterSearchObj: any){
    var returnQueryString = "?";
    if(filterSearchObj.uid){
      returnQueryString = returnQueryString + "uid=" + filterSearchObj.uid + "&";
    }
    if(filterSearchObj.cid){
      returnQueryString = returnQueryString + "cid=" + filterSearchObj.cid + "&";
    }
    if(filterSearchObj.company_name){
      returnQueryString = returnQueryString + "company_name=" + filterSearchObj.company_name + "&";
    }
    if(filterSearchObj.warehouse_name){
      returnQueryString = returnQueryString + "warehouse_name=" + filterSearchObj.warehouse_name + "&";
    }
    if(filterSearchObj.product_name){
      returnQueryString = returnQueryString + "product_name=" + filterSearchObj.product_name + "&";
    }

    return returnQueryString;
  }

  generateFilterQuery(filterSearchObj : any){
    var returnQueryString = "?";
    if(filterSearchObj.uid){
      returnQueryString = returnQueryString + "uid=" + filterSearchObj.uid + "&";
    }

    if(filterSearchObj.cid){
      returnQueryString = returnQueryString + "cid=" + filterSearchObj.cid + "&";
    }

    if(filterSearchObj.startDate){
      returnQueryString = returnQueryString + "startDate=" + filterSearchObj.startDate.toString() + "&";
    }

    if(filterSearchObj.endDate){
      returnQueryString = returnQueryString + "endDate=" + filterSearchObj.endDate.toString() + "&";
    }

    if(filterSearchObj.status){
      returnQueryString = returnQueryString + "status=" + filterSearchObj.status + "&";
    }

    if(filterSearchObj.sender){
      returnQueryString = returnQueryString + "sender=" + filterSearchObj.sender + "&";
    }

    if(filterSearchObj.company){
      returnQueryString = returnQueryString + "company=" + filterSearchObj.company + "&";
    }

    if(returnQueryString[returnQueryString.length -1] === '&'){
      returnQueryString = returnQueryString.substr(0, returnQueryString.length -1);
    }
    return returnQueryString;
  }
}
