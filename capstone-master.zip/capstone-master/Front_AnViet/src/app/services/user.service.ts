import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(  private router: Router,
                private http: HttpClient) { }

  getCurrentUser(){
    return JSON.parse(localStorage.getItem('user'));
  }

  isAuthenticated(){
    if(JSON.parse(localStorage.getItem('user'))){
      return true;
    }
    return false;
  }

  isAdmAccount(){
    if(!this.isAuthenticated()){
      return false;
    }
    if(JSON.parse(localStorage.getItem('user')).type === '2' ){
      return true;
    }
    return false;
  }

  isMngAccount(){
    if(!this.isAuthenticated()){
      return false;
    }
    if(JSON.parse(localStorage.getItem('user')).type === '1'){
      return true;
    }
    return false;
  }

  isCusAccount(){
    if(!this.isAuthenticated()){
      return false;
    }
    if(JSON.parse(localStorage.getItem('user')).type === '0'){
      return true;
    }
    return false;
  }

  logout(){
    localStorage.setItem('user', null);
    localStorage.setItem('currentCompany', null);

    this.http.get('api/v1/logout').subscribe( data =>{
      var retData : any = data;
      if(retData.redirect){
        this.router.navigate([retData.redirect]);
      }
    });
  }

  login(user: string, password: string){
    var loginUser = { "username": user, "password": password};
    return this.http.post('api/v1/login', JSON.stringify(loginUser),{headers:{'api-key': 'anviet',
                                                                              'Content-Type': 'application/json'}});
  }

  userRegister( newUser : any){
    return this.http.post('api/v1/register', JSON.stringify(newUser),{headers:{'api-key': 'anviet',                                                        'Content-Type': 'application/json'}} );
  }

  getAllRelatedCompanies(){
    return JSON.parse(localStorage.getItem('user')).companies;
  }

  setSelectedCompany(company : any){
    localStorage.setItem('currentCompany', JSON.stringify(company));
  }

  getSelectedCompany(){
    return JSON.parse(localStorage.getItem('currentCompany'));
  }

  setCurrentCompanyOnChange(companyName : string){
    this.getAllRelatedCompanies().forEach( company =>{
      if(company.companyShortName === companyName){
        this.setSelectedCompany(company);
      }
    });
  }
}
