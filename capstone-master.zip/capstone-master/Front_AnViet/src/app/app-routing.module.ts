import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountsComponent } from './components/accounts/accounts.component';
import { AccountComponent } from './components/account/account.component';
import { RequestsComponent } from './components/requests/requests.component';
import { RequestComponent } from './components/request/request.component';
import { ProductsComponent } from './components/products/products.component';
import { ProductComponent } from './components/product/product.component';
import { InventoriesComponent } from './components/inventories/inventories.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { WarehousesComponent } from './components/warehouses/warehouses.component';
import { WarehouseComponent } from './components/warehouse/warehouse.component';
import { ActivitiesComponent } from './components/activities/activities.component';
import { ActivityComponent } from './components/activity/activity.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AccountMngComponent } from './components/account-mng/account-mng.component';
import { CompaniesComponent} from './components/companies/companies.component'
import { CompanyComponent} from './components/company/company.component'
import { EmployeesComponent} from './components/employees/employees.component'
import { NavComponent } from './components/nav/nav.component';
import { BillsComponent } from './components/bills/bills.component';



const routes: Routes = [  {path: 'login', component: LoginComponent},
                          {path: 'admin/accounts', component: AccountsComponent},
                          {path: 'account', component: AccountComponent},
                          {path: 'requests', component: RequestsComponent},
                          {path: 'inventories', component: InventoriesComponent},
                          {path: 'products', component: ProductsComponent},
                          {path: 'activities', component: ActivitiesComponent},
                          {path: 'home', component: HomeComponent},
                          {path: 'admin/warehouses', component: WarehousesComponent},
                          {path: 'register', component: RegisterComponent},
                          {path: 'admin/accounts/:uid', component: AccountMngComponent },
                          {path: 'admin/companies', component: CompaniesComponent,},
                          {path: 'admin/companies/:cid', component: CompanyComponent },
                          {path: 'admin/companies/:cid/employees', component: EmployeesComponent },
                          {path: 'bills', component: BillsComponent}
                        ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
