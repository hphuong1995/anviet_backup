import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './components/nav/nav.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import { AccountComponent } from './components/account/account.component';
import { RequestsComponent } from './components/requests/requests.component';
import { RequestComponent } from './components/request/request.component';
import { ProductsComponent } from './components/products/products.component';
import { ProductComponent } from './components/product/product.component';
import { InventoriesComponent } from './components/inventories/inventories.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { WarehousesComponent } from './components/warehouses/warehouses.component';
import { WarehouseComponent } from './components/warehouse/warehouse.component';
import { ActivitiesComponent } from './components/activities/activities.component';
import { ActivityComponent } from './components/activity/activity.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { BillsComponent } from './components/bills/bills.component';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AccountMngComponent } from './components/account-mng/account-mng.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MaterialModule} from "./app.material.module";
import { CompaniesComponent } from './components/companies/companies.component';
import { CompanyComponent } from './components/company/company.component';
import { EmployeesComponent } from './components/employees/employees.component';


@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    AccountsComponent,
    AccountComponent,
    RequestsComponent,
    RequestComponent,
    ProductsComponent,
    ProductComponent,
    InventoriesComponent,
    InventoryComponent,
    WarehousesComponent,
    WarehouseComponent,
    ActivitiesComponent,
    ActivityComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    AccountMngComponent,
    CompaniesComponent,
    CompanyComponent,
    EmployeesComponent,
    BillsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule ,
    BrowserModule,
    // import HttpClientModule after BrowserModule.
    HttpClientModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
