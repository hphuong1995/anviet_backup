var pool = require('./dbConnect');
const uuid = require('uuid/v1');

/**
* USER REGISTER
*/
module.exports.userRegister = (email, password, type, phone, callback) => {
  //console.log(password);
  var query = "SELECT * FROM user where email = '" + email + "'";
  pool.query(query,function(errors, results, field){
    if(errors) throw errors;

    if(results.length !== 0){
      callback({'valid' : false}, { message: 'email already exisit'});
      return;
    }
    else{
      query = "INSERT INTO user (uid, email, password, type, shortName) VALUES (?,?,?,?,?)";
      let registerId = uuid();
      pool.query(query,[registerId, email, password, type,""], function(errors, results, field){
        if(errors) throw errors;
        let phoneQuery = "INSERT INTO phone (uid, phoneNumber) VALUES (?,?)";

        pool.query(phoneQuery, [registerId, phone], (errors, results, field) =>{
          if(errors) throw errors;

          callback({'valid': true}, undefined);
        });
      });
    }
  });
}

/**
* UPDATE ACCOUNT INFO
*/
module.exports.updateAccountInfo = ( newUserInfo, callback) => {
  let query = "UPDATE user SET email = '" + newUserInfo.email +
                              "' , shortName = '" + newUserInfo.shortName +
                              "' , type = '" + newUserInfo.type +
            "' WHERE uid ='" + newUserInfo.uid + "'";

  pool.query( query, (err, updatedInfo, field)=>{
    if (err) {
      callback(err);
      return;
    }
    else{
      var phoneQuery = "UPDATE phone SET phoneNumber = '" + newUserInfo.phone + "' WHERE uid ='" + newUserInfo.uid + "'";
      pool.query(phoneQuery, (err, newUserPhone, field) =>{
        if(err) {
          callback(err);
          return;
        }
        else{
          callback(newUserInfo);
        }
      });
    }
  });
}
  // var query = "SELECT * FROM user WHERE uid = 'newUserInfo.uid'";
  // console.log(newUserInfo.uid);
  // pool.query(query, (err, results, fields)=>{
  //
  //   if(err) throw err;
  //
  //   if(results.length !== 0){
  //     callback({message: 'user Code alrady exist'});
  //   }
  //   else{
  //
  // });


/**
* ADMIN GET ALL USERS
*/
module.exports.getAllAccountsAsAdmin = ( callback) => {
  var query = "SELECT * FROM user";
  pool.query(query, (err, accounts, field) =>{
    if(err) throw err;
    callback(accounts);
  });
}

/**
* ADMIN GET AN USERS
*/
module.exports.getAnAccountAsAdmin = (uid, callback) => {
  var query = "SELECT * FROM user WHERE uid = '" + uid + "'";
  pool.query(query, (err, account, field) =>{
    if(err) throw err;
    var phoneQuery = "SELECT * FROM phone WHERE uid = '" + uid + "'";
    pool.query(phoneQuery, (err, userPhone, field) =>{
      if(err) {
        callback(err);
        return;
      }
      else{
        account[0].phone = userPhone[0].phoneNumber;
        var companiesQuery = "SELECT cid, companyShortName FROM user_company JOIN company ON company_cid = cid  WHERE user_uid = '" + uid + "'";
        pool.query(companiesQuery, (err, companies, field) =>{
          if(err) {
            callback(err);
            return;
          }
          else{
            account[0].companies = companies;
            delete account[0].password;
            callback(account[0]);
          }
        });
      }
    });
  });
}

/**
* MANAGER GET ALL USERS
*/
module.exports.getAllAccountsAsManager = ( callback) => {
  var query = "SELECT uid, shortName, type, email FROM user WHERE type ='0'" ;
  pool.query(query, (err, accounts, field) =>{
    if(err) throw err;

    callback(accounts);
  });
}

/**
* MANAGER / ADMIN  GET ALL USERS
*/
module.exports.getAllRequests = ( queryObj,  callback) => {
  var query = "SELECT message, rid, shortName, date, user_id, status, companyShortName FROM request JOIN user ON user_id = uid JOIN company ON company_id = cid" ;
  pool.query(query, (err, requests, field) =>{
    if(err) throw err;
    requests = filterRequestHelper(requests, queryObj);

    callback(requests);
  });
}

function filterRequestHelper(requests, queryObj){
  requests = requests.filter( request =>{
    if(queryObj.company){
      if(!request.companyShortName.toLowerCase().includes(queryObj.company.toLowerCase())){
        return false;
      }
    }

    if(queryObj.sender){
      if(!request.shortName.toLowerCase().includes(queryObj.sender.toLowerCase())){
        return false;
      }
    }

    if(queryObj.status){
      if(request.status !== queryObj.status){
        return false;
      }
    }

    if(queryObj.startDate && !queryObj.endDate){
      reqDate = new Date(request.date).getTime();
      startDate = new Date(queryObj.startDate).getTime();
      if( startDate > reqDate){
        return false;
      }
    }

    if(!queryObj.startDate && queryObj.endDate){
      reqDate = new Date(request.date).getTime();
      endDate = new Date(queryObj.endDate).getTime()
      if( endDate < reqDate){
        return false;
      }
    }

    if(queryObj.startDate && queryObj.endDate){
      reqDate = new Date(request.date).getTime();
      startDate = new Date(queryObj.startDate).getTime();
      endDate = new Date(queryObj.endDate).getTime()
      if( startDate > reqDate || endDate < reqDate){
        return false;
      }
    }


    return true;
  });

  return requests;
}

/**
* MANAGER OR ADMIN GET ALL PRODUCTS
*/
module.exports.getAllActivitiesByAdmMng = (requestObj, callback )=>{
  var query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid JOIN company ON inven_company_cid = cid JOIN user ON activity_mng_uid = uid JOIN warehouse ON inven_wh_wid = wid JOIN product ON inven_prod_pid = pid JOIN item_unit ON inven_unit_uid = unit_uid JOIN request ON activity_request_rid = rid";
  pool.query(query, (err, activities, field)=>{
    if(err) throw err;

    activities = filterActivityHelper(activities, requestObj);

    callback(activities)
  });
}


function filterActivityHelper(activities, queryObj){
  activities = activities.filter( activity =>{



    if(queryObj.startDate && !queryObj.endDate){
      reqDate = new Date(activity.activity_date).getTime();
      startDate = new Date(queryObj.startDate).getTime();
      if( startDate > reqDate){
        return false;
      }
    }

    if(!queryObj.startDate && queryObj.endDate){
      reqDate = new Date(activity.activity_date).getTime();
      endDate = new Date(queryObj.endDate).getTime()
      if( endDate < reqDate){
        return false;
      }
    }

    if(queryObj.startDate && queryObj.endDate){
      reqDate = new Date(activity.activity_date).getTime();
      startDate = new Date(queryObj.startDate).getTime();
      endDate = new Date(queryObj.endDate).getTime()
      if( startDate > reqDate || endDate < reqDate){
        return false;
      }
    }

    if(queryObj.company){
      if(!activity.companyShortName.toLowerCase().includes(queryObj.company.toLowerCase())){
        return false;
      }
    }

    if(queryObj.code){
      if(activity.aid !== queryObj.code){
        return false;
      }
    }

    if(queryObj.product){
      if(!activity.prodCode.toLowerCase().includes(queryObj.product.toLowerCase())){
        return false;
      }
    }

    if(queryObj.warehouse){
      if(!activity.warehouseCode.toLowerCase().includes(queryObj.warehouse.toLowerCase())){
        return false;
      }
    }

    if(queryObj.type){
      if(activity.activity_type !== queryObj.type){
        return false;
      }
    }

    if(queryObj.status){
      if(activity.activity_status !== queryObj.status){
        return false;
      }
    }

    return true;
  });

  return activities;
}

/**
* CUSTOMER  GET ALL REQUESTS
*/
module.exports.getAllRequestsByCus = (queryObj, uid, cid, callback) => {
  var query = "SELECT message, rid, date, shortName, user_id, status, companyShortName FROM request JOIN user ON user_id = uid JOIN company ON company_id = cid WHERE user_id ='" + uid  + "' AND company_id='" + cid + "'" ;
  pool.query(query, (err, requests, field) =>{
    if(err) throw err;
    requests = filterRequestHelper(requests, queryObj);

    callback(requests);
  });
}

/**
* CUSTOMER  GET CUSTOMER
*/
module.exports.getOneRequestsByCus = (rid, callback) => {
  var query = "SELECT shortName, type, rid, user_id, company_id, status, date, req_mng_uid, req_driver_plate, message FROM request JOIN user ON user_id = uid WHERE rid = '" + rid + "'";
  pool.query(query, (err, request, field) =>{
    if(err) throw err;

    query = "SELECT * FROM request_item JOIN item_unit ON item_unit_uid = unit_uid WHERE request_rid = '" + rid + "';" ;
    pool.query(query, (err, request_items, field) =>{
      if(err) throw err;
      query = "SELECT * FROM activity WHERE activity_request_rid = '" + rid + "'" ;

      pool.query(query, (err, activities, field) =>{
        if(err) throw err;

        request[0].activities = activities;
        request[0].items = request_items;
        callback(request[0]);
      });
    });
  });
}

/**
* CUSTOMER  GET CUSTOMER
*/
module.exports.getOneRequestsByAdmOrMng = (rid, callback) => {
  var query = "SELECT shortName, type, rid, user_id, company_id, status, date, req_mng_uid, req_driver_plate, message FROM request JOIN user ON user_id = uid WHERE rid = '" + rid + "'";
  pool.query(query, (err, request, field) =>{
    if(err) throw err;
    query = "SELECT * FROM request_item JOIN item_unit ON item_unit_uid = unit_uid WHERE request_rid ='" + rid + "';" ;
    pool.query(query, (err, request_items, field) =>{
      if(err) throw err;

      query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid JOIN warehouse ON inven_wh_wid = wid JOIN product ON inven_prod_pid = pid JOIN item_unit ON inven_unit_uid = unit_uid WHERE activity_request_rid = '" + rid + "'" ;

      pool.query(query, (err, activities, field) =>{
        if(err) throw err;

        request[0].activities = activities;
        request[0].items = request_items
        callback(request[0]);
      });
    });
  });
}


/**
* CUSTOMER  GET CUSTOMER
*/
module.exports.getAllProductOfACompany = (cid, callback) => {
  var query = "SELECT  * FROM inventory JOIN product ON pid = inven_prod_pid WHERE inven_company_cid ='" + cid + "' GROUP BY prodName;" ;
  pool.query(query, (err, products, field) =>{
    if(err) throw err;

    callback(products);
  });
}

/**
* CUSTOMER  GET CUSTOMER
*/
module.exports.createNewInvenBeforeCreateActivity = (newActivityObj, callback) => {
  var query = "INSERT INTO inventory (iid, inven_company_cid, inven_wh_wid, inven_prod_pid, inven_amount, inven_unit_uid, inven_expire_date) VALUES ?" ;
  let newInventoryId = uuid();
  let values = [
    [newInventoryId, newActivityObj.activity_company_cid, newActivityObj.activity_newInven_warehouse, newActivityObj.activity_newInven_product, '0' , newActivityObj.activity_newInven_unit, newActivityObj.activity_newInven_expireDate]
  ];

  pool.query(query, [values], (err, newInventory, field) =>{
    if(err) throw err;

    query = "INSERT INTO activity (activity_mng_uid, activity_request_rid, activity_amount, activity_inven_iid, activity_date, activity_type, activity_status, activity_work_type) VALUES ?" ;

    let values = [
      [newActivityObj.activity_mng_uid, newActivityObj.activity_request_rid, newActivityObj.activity_amount, newInventoryId, newActivityObj.activity_date, newActivityObj.activity_type, newActivityObj.activity_status, newActivityObj.activity_work_type]
    ];
    pool.query(query,[values], (err, newActivity, field) =>{
      if(err) throw err;

      let query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid JOIN warehouse ON inven_wh_wid = wid JOIN product ON inven_prod_pid = pid JOIN item_unit ON inven_unit_uid = unit_uid WHERE activity_request_rid = '" + newActivityObj.activity_request_rid + "'";

      pool.query(query, (err, activities, field) =>{
        if(err) throw err;

        callback(activities);
      });
    });
  });
}

module.exports.deleteActivityByAdmOrMng = (activityObj, callback) => {
  // delete inventory first then delete activity
  if(activityObj.activity_type === "Import" && parseInt(activityObj.inven_amount) === 0){
    let query = "DELETE FROM inventory WHERE iid ='" + activityObj.activity_inven_iid + "'";

    pool.query(query, (err, messageDel, field) =>{
      query = "DELETE FROM activity WHERE aid = " + activityObj.aid;
      pool.query(query, (err, messageDel, field) =>{
        if(err) throw err;

        let query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid JOIN warehouse ON inven_wh_wid = wid JOIN product ON inven_prod_pid = pid JOIN item_unit ON inven_unit_uid = unit_uid WHERE activity_request_rid = '" + activityObj.activity_request_rid + "'";

        pool.query(query, (err, activities, field) =>{
          if(err) throw err;

          callback(activities);
        });
      });
    });
  }
  else{
    let query = "DELETE FROM activity WHERE aid = " + activityObj.aid;
    pool.query(query, (err, messageDel, field) =>{
      if(err) throw err;

      let query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid JOIN warehouse ON inven_wh_wid = wid JOIN product ON inven_prod_pid = pid JOIN item_unit ON inven_unit_uid = unit_uid WHERE activity_request_rid = '" + activityObj.activity_request_rid + "'";

      pool.query(query, (err, activities, field) =>{
        if(err) throw err;

        callback(activities);
      });
    });
  }
}


module.exports.createNewActivityForRequest = (newActivityObj, callback) => {
  var query = "INSERT INTO activity (activity_mng_uid, activity_request_rid, activity_amount, activity_inven_iid, activity_date, activity_type, activity_status, activity_work_type) VALUES ?" ;

  let values = [
    [newActivityObj.activity_mng_uid, newActivityObj.activity_request_rid, newActivityObj.activity_amount, newActivityObj.activity_inven_iid, newActivityObj.activity_date, newActivityObj.activity_type, newActivityObj.activity_status, newActivityObj.activity_work_type]
  ];
  pool.query(query,[values], (err, newActivity, field) =>{
    if(err) throw err;

    let query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid JOIN warehouse ON inven_wh_wid = wid JOIN product ON inven_prod_pid = pid JOIN item_unit ON inven_unit_uid = unit_uid WHERE activity_request_rid = '" + newActivityObj.activity_request_rid + "'";

    pool.query(query, (err, activities, field) =>{
      if(err) throw err;

      callback(activities);
    });
  });
}


/**
* MANAGER OR ADMIN UPDATE REQUEST STATUS
*/
module.exports.denyRequestByMngOrAdm = (rid, reqObj, callback) =>{
  var query = "SELECT * FROM request WHERE rid = '" + rid + "'";
  pool.query(query, (err, request, field) =>{
    if(err) throw err;
    console.log(request[0].status);
    if(request[0].status !== "Pending"){
      callback(null, { message: "User can only deny Pending request"});
    }
    else{
      if(reqObj.message){
        query = "UPDATE request SET status = '" + reqObj.updatingStatus + "', message = '"+ reqObj.message  + "' WHERE rid = '" + rid + "'";
      }
      else{
        query = "UPDATE request SET status ='" + reqObj.updatingStatus + "' WHERE rid = '" + rid + "'";
      }
      pool.query(query, (err, newRequests, field) =>{
        if(err) throw err;

        query = "UPDATE activity SET activity_status = '"+ reqObj.updatingStatus + "' WHERE activity_request_rid = '" + rid + "'";

        pool.query(query, (err, newRequests, field) =>{
          if(err) throw err;

          callback(newRequests);
        });
      });
    }
  });
}


module.exports.validateByMngOrAdm = (rid, reqObj, callback) =>{
  let query = "SELECT * FROM activity WHERE activity_request_rid = '" + rid + "'";

  pool.query(query, (err, activities, field) =>{
    if(err) throw err;

    query = "SELECT * FROM inventory WHERE " + generateApproveReqQueryForInven(activities) ;

    pool.query(query, (err, inventories, field) =>{
      if(err) throw err;

      query = "SELECT * FROM request WHERE rid = '" + rid + "'";
      pool.query(query, (err, request, field) =>{
        if(err) throw err;
        if(request[0].status !== "Approved"){
          callback(null, { message: "User can only validate Approved request"});
        }
        else{

          query = "UPDATE request SET status ='" + reqObj.updatingStatus + "' WHERE rid = '" + rid + "'";

          pool.query(query, (err, newRequests, field) =>{
            if(err) throw err;

            inventories = calculateNewInvenAmount(activities, inventories);

            query = "UPDATE inventory SET inven_amount = ("  + generateUpdateInventoryAmountQuery(inventories) + ")\
                            WHERE iid IN (" + generateInventoryIdList(inventories) +  ") ;";
            console.log(query);

            pool.query(query, (err, updatedField, field) =>{
              if(err) throw err;

              query = "UPDATE activity SET activity_status = 'Validated' WHERE activity_request_rid = '" + rid + "'";

              pool.query(query, (err, updatedField, field) =>{
                if(err) throw err;

                callback({success: "HUHAAA"});
              });
            });
          });
        }
      });
    });
  });
}

function generateInventoryIdList(inventories){
  let retStr = "";

  console.log( inventories);
  inventories.forEach( inventory =>{
    retStr = retStr + " '" + inventory.iid + "' ,";
  });

  return retStr.substr(0,retStr.length - 2);
}

function generateUpdateInventoryAmountQuery( inventories){
  let retStr = "CASE ";

  inventories.forEach( inventory =>{
    retStr = retStr + "WHEN iid = '" + inventory.iid + "' THEN '" + inventory.inven_amount + "' ";
  });

  retStr = retStr + " END";
  return retStr;
}

function calculateNewInvenAmount(activities, inventories){
  let cloneInventoryList = JSON.parse(JSON.stringify(inventories));
  let cloneActivityList = JSON.parse(JSON.stringify(activities));

  cloneActivityList.forEach( activity=>{
    activity.activity_amount = parseInt(activity.activity_amount);
    cloneInventoryList.forEach(inventory =>{
      inventory.inven_amount = parseInt(inventory.inven_amount);
      if(activity.activity_inven_iid === inventory.iid){
        if(activity.activity_type === "Export"){
          console.log(inventory.inven_amount + " minus " + activity.activity_amount);
          inventory.inven_amount = inventory.inven_amount - activity.activity_amount;
        }
        else{
          inventory.inven_amount = inventory.inven_amount + activity.activity_amount;
        }
      }
    });
  });

  return cloneInventoryList;
}

function generateApproveReqQueryForAct( activities){
  let first  = true;
  let retStr = "";
  activities.forEach( activity =>{
    if(first){
      retStr = retStr + "activity_inven_iid ='" + activity.activity_inven_iid + "'";
      first = false;
    }
    else{
      retStr = retStr + " OR activity_inven_iid ='" + activity.activity_inven_iid + "'";
    }
  })
  return retStr;
}

function generateApproveReqQueryForInven( activities){
  let first  = true;
  let retStr = "";
  activities.forEach( activity =>{
    if(first){
      retStr = retStr + "iid ='" + activity.activity_inven_iid + "'";
      first = false;
    }
    else{
      retStr = retStr + " OR iid ='" + activity.activity_inven_iid + "'";
    }
  })
  return retStr;
}

function checkValidActivity( activities, inventories){
  let cloneInventoryList = JSON.parse(JSON.stringify(inventories));
  let cloneActivityList = JSON.parse(JSON.stringify(activities));

  cloneActivityList.forEach( activity=>{
    activity.activity_amount = parseInt(activity.activity_amount);
    cloneInventoryList.forEach(inventory =>{
      inventory.inven_amount = parseInt(inventory.inven_amount);
      if(activity.activity_inven_iid === inventory.iid){
        if(activity.activity_type === "Export"){
          inventory.inven_amount = inventory.inven_amount - activity.activity_amount;
        }
        else{
          inventory.inven_amount = inventory.inven_amount + activity.activity_amount;
        }
      }
    });
  });

  let flag = true;

  cloneInventoryList.forEach( inventory =>{
    if(inventory.inven_amount < 0 ){
      flag = false;
    }
  });
  return flag;
}

/**
* MANAGER OR ADMIN APRROVE REQUEST
*/
module.exports.approveRequestByMngOrAdm = (rid, reqObj, callback) =>{
  let query = "SELECT * FROM activity WHERE activity_status = 'Approved' AND (" + generateApproveReqQueryForAct(reqObj.activities) + ");";

  pool.query(query, (err, activities, field) =>{
    if(err) throw err;

    query = "SELECT * FROM inventory WHERE " + generateApproveReqQueryForInven(reqObj.activities) ;

    pool.query(query, (err, inventories, field) =>{
      if(err) throw err;

      if(!checkValidActivity(reqObj.activities.concat(activities), inventories)){
        callback(null, {message: "At least one of the activity is not approvable."})
      }
      else{
        query = "SELECT * FROM request WHERE rid = '" + rid + "'";
        pool.query(query, (err, request, field) =>{
          if(err) throw err;
          if(request[0].status !== "Pending"){
            callback(null, { message: "User can only deny Pending request"});
          }
          else{
            if(reqObj.message){
              query = "UPDATE request SET status = '" + reqObj.updatingStatus + "', message = '"+ reqObj.message  +
                        "' , req_driver_plate = '" + reqObj.driver_plate + "' WHERE rid = '" + rid + "'";
            }
            else{
              query = "UPDATE request SET status ='" + reqObj.updatingStatus +
                      "', req_driver_plate = '" + reqObj.driver_plate + "' WHERE rid = '" + rid + "'";
            }

            pool.query(query, (err, newRequests, field) =>{
              if(err) throw err;

              query = "UPDATE activity SET activity_status = '"+ reqObj.updatingStatus + "' WHERE activity_request_rid = '" + rid + "'";

              pool.query(query, (err, newRequests, field) =>{
                if(err) throw err;

                callback({success: "true"});
              });
            });
          }
        });
      }
    });
  });
}



/**
* MANAGER OR ADMIN UPDATE REQUEST STATUS
*/
module.exports.updateRequestItemProductId = (item_iid, reqObj, callback) =>{
  var query = "UPDATE request_item SET item_product_pid = '" + reqObj.product_pid + "' WHERE item_iid = " + item_iid + ";";
  pool.query(query, (err, updatedRequestItem, field) =>{
    if(err) throw err;

    query = "SELECT * FROM request JOIN request_item ON rid = request_rid WHERE rid = '" + reqObj.request_rid + "';";
    pool.query(query, (err, updatedRequest, field) =>{
      if(err) throw err;

      callback(updatedRequest);
    });
  });
}


function checkUserCompanyProcessRequest(user, company_id){
  let flag = false;
  console.log( user.companies, company_id);
  user.companies.forEach( company =>{
      if(company.company_cid === company_id){
        flag = true;
      }
  });

  return flag;
}

//approveRequest

module.exports.approveCancelationByMngOrAdm = (rid, reqObj, callback) =>{
  var query = "SELECT * FROM request WHERE rid = '" + rid + "'";
  pool.query(query, (err, request, field) =>{
    if(err) throw err;

    if(request[0].status === "Cancel Pending"){
      query = "UPDATE request SET status = 'Cancelled', message = '"+ reqObj.message  + "' WHERE rid = '" + rid + "'";
      console.log(query);
      pool.query(query, (err, newRequests, field) =>{
        if(err) throw err;

        query = "UPDATE activity SET activity_status = 'Cacnelled' WHERE activity_request_rid = '" + rid + "'";

        pool.query(query, (err, newRequests, field) =>{
          if(err) throw err;

          callback(newRequests);
        });
      });
    }
    else{
      callback( null , {message: "Only can cancel request with cancel pending status"});
    }
  });
}

module.exports.denyCancelationByMngOrAdm = (rid, reqObj, callback) =>{
  var query = "SELECT * FROM request WHERE rid = '" + rid + "'";
  pool.query(query, (err, request, field) =>{
    if(err) throw err;

    if(request[0].status === "Cancel Pending"){
      query = "UPDATE request SET status = 'Validated', message = '"+ reqObj.message  + "' WHERE rid = '" + rid + "'";
      pool.query(query, (err, newRequests, field) =>{
        if(err) throw err;

        // VALIDATE
        callback(newRequests);
      });
    }
    else{
      callback( null , {message: "Only can cancel request with cancel pending status"});
    }
  });
}


module.exports.generateBillByAdm = (reqObj, callback) =>{
  let query = "SELECT * FROM company WHERE companyShortName ='"+ reqObj.company + "';";
  pool.query(query, (err, company, field) =>{
    if(err) throw err;

    query = "SELECT * FROM daily_bill WHERE daily_bill_company_cid = '" + company[0].cid + "';";

    pool.query(query, (err, bills, field) =>{
      if(err) throw err;

      bills = filterBillHelper(reqObj, bills);
      company[0].bills = bills;
      callback(company[0]);
    });
  });
}

module.exports.generateBillByCus = (userObj, reqObj, callback) =>{
  let query = "SELECT * FROM company WHERE companyShortName ='"+ reqObj.company + "';";
  pool.query(query, (err, company, field) =>{
    if(err) throw err;

    query = "SELECT viewBill FROM user_company WHERE user_uid ='" + userObj.uid +"' AND company_cid = '" + company[0].cid + "';";

    pool.query(query, (err, privilege, field) =>{
      if(err) throw err;

      console.log(privilege);
      if(privilege.length === 0){
        callback(null, {message: "Forbidden, User and Company does not match!"});
      }
      else if(privilege[0].viewBill !== '1'){
        callback(null, {message: "Forbidden, This user does not have view Bill privilege!"});
      }
      else{
        query = "SELECT * FROM daily_bill WHERE daily_bill_company_cid = '" + company[0].cid + "';";

        pool.query(query, (err, bills, field) =>{

          bills = filterBillHelper(reqObj, bills);
          company[0].bills = bills;
          callback(company[0]);
        });
      }
    });
  });
}

filterBillHelper = function(queryObj, bills){
  bills = bills.filter( bill =>{

    if(queryObj.startDate && queryObj.endDate){
      billDate = new Date(bill.daily_bill_date).getTime();
      startDate = new Date(queryObj.startDate).getTime();
      endDate = new Date(queryObj.endDate).getTime();
      today = new Date();
      today.setHours(0,0,0,0);
      today = today.getTime();
      // console.log(new Date(bill.daily_bill_date));
      // console.log(new Date(queryObj.startDate));
      // console.log(new Date(queryObj.endDate));
      if( startDate > billDate || endDate < billDate){
        return false;
      }
      if(billDate === today){
        return false;
      }
    }
    return true;
  });

  return bills;
}

module.exports.cancelRequestByCustomer = (rid, reqObj, callback) =>{
  var query = "SELECT * FROM request WHERE rid = '" + rid + "'";
  pool.query(query, (err, request, field) =>{
    if(err) throw err;

    if(!checkUserCompanyProcessRequest(reqObj.user, request[0].company_id)){
      callback(null, { message: "User is not authorized for this Operation"})
    }
    else if(request[0].status === "Pending"){
      query = "UPDATE request SET status = 'Canceled' WHERE rid = '" + rid + "'";
      pool.query(query, (err, newRequests, field) =>{
        if(err) throw err;
        callback(newRequests);
      });
    }
    else if (request[0].status === "Approved"){
      query = "UPDATE request SET status = 'Cancel Pending' WHERE rid = '" + rid + "'";
      pool.query(query, (err, newRequests, field) =>{
        if(err) throw err;
        callback(newRequests);
      });
    }
    else{
      callback( null , {message: "only cancel pending request or approved request"});
    }
  });
}




/**
* MANAGER OR ADMIN GET ALL PRODUCTS
*/
module.exports.getAllProdsByAdmOrMng = ( callback )=>{
  var query = "SELECT * FROM product";
  pool.query(query, (err, products, field)=>{
    if(err) throw err;
    callback(products)
  });
}

module.exports.updateProduct = (updateObj, callback )=>{
  var query = "UPDATE product SET prodName ='" + updateObj.prodName + "', prodCode ='" + updateObj.prodCode + "' WHERE pid ='" + updateObj.pid +"';";
  console.log(query);
  pool.query(query, (err, warehouses, field)=>{
    if(err) throw err;
    query = "SELECT * FROM product";

    pool.query(query, (err, products, field)=>{
      if(err) throw err;
      callback(products)
    });
  });
}
/**
* MANAGER OR ADMIN GET ALL WARE HOUSES
*/
module.exports.getAllWareHousesByAdmOrMng = ( callback )=>{
  var query = "SELECT * FROM warehouse";
  pool.query(query, (err, warehouses, field)=>{
    if(err) throw err;
    callback(warehouses)
  });
}


module.exports.deleteProduct = (pid,  callback )=>{
  var query = "SELECT * FROM product JOIN inventory ON pid = inven_prod_pid WHERE pid =" + pid;
  console.log(query);
  pool.query(query, (err, products, field)=>{
    if(err) throw err;

    console.log(products);

    if(products.length !== 0){
      callback(null, {message: "Product can not be delete"});
      return;
    }
    else{
      var query = "SELECT * FROM product JOIN request_item ON pid = item_product_pid WHERE pid =" + pid;
      pool.query(query, (err, products, field)=>{
        if(err) throw err;
        if(products.length !== 0){
          callback(null, {message: "Product can not be delete"});
          return;
        }
        else{
          query = "DELETE FROM product WHERE pid =" + pid;

          pool.query(query, (err, products, field)=>{
            if(err) throw err;

            query = "SELECT * FROM product";
            pool.query(query, (err, products, field)=>{
              if(err) throw err;
              callback(products);
            });
          });
        }
      });

    }
  });
}

module.exports.updateWarehouse = (updateObj, callback )=>{
  var query = "UPDATE warehouse SET warehouseName ='" + updateObj.warehouseName + "', warehouseCode ='" + updateObj.warehouseCode + "' , avaSpace = '" + updateObj.availableSpace + "' WHERE wid ='" + updateObj.wid +"';";
  console.log(query);
  pool.query(query, (err, warehouses, field)=>{
    if(err) throw err;
    query = "SELECT * FROM warehouse";

    pool.query(query, (err, warehouses, field)=>{
      if(err) throw err;
      callback(warehouses)
    });
  });
}

/**
* MANAGER OR ADMIN GET ALL Companies
*/
module.exports.getAllCompaniesByAdmOrMng = ( callback) =>{
  var query = "SELECT * FROM company";
  pool.query(query, (err, companies, field)=>{
    if(err) throw err;
    callback(companies)
  });
}

module.exports.getAllCompaniesRelateToAnUserByAdmOrMng = (queryObj, callback)=>{
  var query = "SELECT cid, uid, shortName, companyShortName FROM company JOIN user_company ON cid = company_cid JOIN user ON user_uid = uid WHERE uid ='" + queryObj.uid + "'";
  pool.query(query, (err, companies, field)=>{
    if(err) throw err;
    callback(companies)
  });
}

/**
* ADMIN Unit List From Server
*/
module.exports.getUnitListFromServer = ( callback) =>{
  var query = "SELECT * FROM item_unit";
  pool.query(query, (err, units, field)=>{
    if(err) throw err;
    callback(units);
  });
}

/**
* ADMIN GET A Company
*/
module.exports.getACompanyByAdm = (cid, callback) =>{
  var query = "SELECT * FROM company WHERE cid ='" + cid + "'";
  pool.query(query, (err, company, field)=>{
    if(err) throw err;
    console.log(company);
    callback(company);
  });
}


/**
* ADMIN GET A Company
*/
module.exports.createNewWarehouseByAdm = (newWarehouseObj, callback) =>{
  var query = "SELECT * FROM warehouse WHERE warehouseCode ='" + newWarehouseObj.warehouseCode + "'";
  pool.query(query, (err, warehouse, field)=>{
    if(err) throw err;

    if(warehouse.length !== 0){
      callback(null, {message: "warehouseCode already Exist"});
    }
    else{
      query = "INSERT INTO warehouse (warehouseName, warehouseCode, avaSpace) VALUES ?";
      let values = [
        [newWarehouseObj.warehouseName, newWarehouseObj.warehouseCode, newWarehouseObj.avaSpace]
      ];
      pool.query(query,[values], (err, company, field)=>{
        if(err) throw err;

        query = "SELECT * FROM warehouse;";
        pool.query(query, (err, warehouses, field)=>{
          if(err) throw err;

          callback(warehouses);
        });
      });
    }
  });
}

module.exports.createNewCompany = (newWarehouseObj, callback) =>{

    query = "INSERT INTO company (cid, companyName, companyShortName, company_email, company_phone, address, taxCode, portFee, storageFee) VALUES ?";
    let values = [
      [uuid(), newWarehouseObj.companyName, newWarehouseObj.companyShortName, newWarehouseObj.email, newWarehouseObj.phone,newWarehouseObj.address, newWarehouseObj.taxCode, newWarehouseObj.portFee, newWarehouseObj.storageFee]
    ];
    pool.query(query,[values], (err, company, field)=>{
      if(err) throw err;

      query = "SELECT * FROM company;";
      pool.query(query, (err, companies, field)=>{
        if(err) throw err;

        callback(companies);
      });
    });

}


module.exports.createProductByAdmOrMng = (newProductObj, callback) =>{
  var query = "SELECT * FROM product WHERE prodCode ='" + newProductObj.prodCode + "'";
  pool.query(query, (err, product, field)=>{
    if(err) throw err;

    if(product.length !== 0){
      callback(null, {message: "warehouseCode already Exist"});
    }
    else{
      query = "INSERT INTO product (prodName, prodCode) VALUES ?";
      let values = [
        [newProductObj.prodName, newProductObj.prodCode]
      ];
      pool.query(query,[values], (err, products, field)=>{
        if(err) throw err;

        query = "SELECT * FROM product;";
        pool.query(query, (err, products, field)=>{
          if(err) throw err;

          callback(products);
        });
      });
    }
  });
}

/**
* ADMIN GET A Company
*/
module.exports.getACompanyByMng = (cid, callback) =>{
  var query = "SELECT companyName, companyShortName,address, company_email,company_phone  FROM company WHERE cid ='"+ cid + "'";
  pool.query(query, (err, company, field)=>{
    if(err) throw err;
    console.log(company);
    callback(company);
  });
}

// /**
// * MANAGER OR ADMIN GET ALL USER RELATE TO A COMPANY
// */
// module.exports.getAllEmployeesOfCompanyByAdmOrMng = (cid, callback) =>{
//   var query = "SELECT company_cid, sendRequest, viewBill, shortName, type, uid FROM user_company JOIN user ON user_uid = uid WHERE company_cid = '" + cid + "'";
//   pool.query(query, (err, employees, field)=>{
//     if(err) throw err;
//     console.log(employees);
//     callback(employees);
//   });
// }

/**
* MANAGER OR ADMIN GET ALL INVENTORIES
*/
module.exports.getAllInventoriesByAdmAndMng = (queryObj, callback) =>{
  var query = "SELECT * FROM inventory JOIN company ON inven_company_cid = cid JOIN product ON inven_prod_pid = pid JOIN warehouse ON inven_wh_wid = wid JOIN item_unit ON inven_unit_uid = unit_uid";
  pool.query(query, (err, inventories, field)=>{
    if(err) throw err;

    inventories = filterInventoryHelper(inventories, queryObj);
    callback(inventories);
  });
}


/**
* CUSTOMER GET ALL INVENTORIES
*/
module.exports.getAllInventoriesByCus = (queryObj, callback) =>{
  var query = "SELECT * FROM inventory JOIN company ON inven_company_cid = cid JOIN product ON inven_prod_pid = pid JOIN warehouse ON inven_wh_wid = wid JOIN item_unit ON inven_unit_uid = unit_uid ";
  pool.query(query, (err, inventories, field)=>{
    if(err) throw err;

    inventories = filterInventoryHelper(inventories, queryObj);
    callback(inventories);
  });
}


function filterInventoryHelper(inventories, queryObj){
  inventories = inventories.filter( inventory =>{
    if(queryObj.company_name){
      if(!inventory.companyShortName.toLowerCase().includes(queryObj.company_name.toLowerCase())){
        return false;
      }
    }

    if(queryObj.product_name){
      if(!inventory.prodName.toLowerCase().includes(queryObj.product_name.toLowerCase())){
        return false;
      }
    }

    if(queryObj.warehouse_name){
      if(!inventory.warehouseName.toLowerCase().includes(queryObj.warehouse_name.toLowerCase())){
        return false;
      }
    }

    if(queryObj.cid){
      if(inventory.inven_company_cid !== queryObj.cid){
        return false;
      }
    }

    return true;
  });

  return inventories;
}


/**
* MANAGER OR ADMIN GET ALL USER RELATE TO A COMPANY
*/
module.exports.updateCompanyInfoByAdm = (newCompanyInfo, callback) =>{
  var query = "UPDATE company SET companyName = '" + newCompanyInfo.companyName +
                              "' , company_email = '" + newCompanyInfo.company_email +
                              "' , company_phone = '" + newCompanyInfo.company_phone +
                              "' , taxCode = '" + newCompanyInfo.taxCode +
                              "' , portFee = '" + newCompanyInfo.portFee +
                              "' , storageFee = '" + newCompanyInfo.storageFee +
                              "' , companyShortName = '" + newCompanyInfo.shortName +
                              "' , address = '" + newCompanyInfo.address +
            "' WHERE cid ='" + newCompanyInfo.cid + "' ";
  pool.query(query, (err, newInfo, field)=>{
    if(err) throw err;

    query = "SELECT * FROM company WHERE cid = '" + newCompanyInfo.cid +"'";
    pool.query(query, (err, newInfo, field)=>{
      if(err) throw err;
      callback(newInfo);
    });
  });
}


/**
* MANAGER OR ADMIN GET ALL USER RELATE TO A COMPANY
*/
module.exports.updateCustomerViewBillRight = (cid, uid, reqObj, callback) =>{
  var query = "UPDATE user_company SET viewBill =" + reqObj.viewBill + " WHERE user_uid = '" + uid + "' AND company_cid = '" + cid + "'";
  console.log(query);
  pool.query(query, (err, newInfo, field)=>{
    if(err) throw err;
    query = "SELECT company_cid, sendRequest, viewBill, shortName, type, uid FROM user_company JOIN user ON user_uid = uid WHERE company_cid = '" + cid + "'";
    pool.query(query, (err, employees, field)=>{
      if(err) throw err;
      console.log(employees);
      callback(employees);
    });
  });
}


/**
* MANAGER OR ADMIN GET ALL USER RELATE TO A COMPANY
*/
module.exports.updateCustomerSendRequestRight = (cid, uid, reqObj, callback) =>{
  var query = "UPDATE user_company SET sendRequest =" + reqObj.sendRequest + " WHERE user_uid = '" + uid + "' AND company_cid = '" + cid + "'";
  console.log(query);
  pool.query(query, (err, newInfo, field)=>{
    if(err) throw err;
    query = "SELECT company_cid, sendRequest, viewBill, shortName, type, uid FROM user_company JOIN user ON user_uid = uid WHERE company_cid = '" + cid + "'";
    pool.query(query, (err, employees, field)=>{
      if(err) throw err;
      console.log(employees);
      callback(employees);
    });
  });
}

/**
* Admin add a company to Account
*/
module.exports.addCompanyToAccountByAdm = (userId, companyId, callback) =>{
  var query = "INSERT INTO user_company (user_uid, company_cid, viewBill, sendRequest) VALUES ?";
  values = [
    [userId, companyId, '0','0']
  ]
  pool.query(query, [values], (err, newEntry, field)=>{
    if(err) throw err;
    callback(newEntry);
  });
}

/**
* Admin Delete a company from Account
*/
module.exports.deleteCompanyFromUserByAdm = (userId, companyId, callback) =>{
  var query = "DELETE FROM user_company WHERE user_uid ='" + userId + "' AND company_cid ='" + companyId + "'";

  pool.query(query, (err, newEntry, field)=>{
    if(err) throw err;
    callback(newEntry);
  });
}

/**
* Customer create new Request
*/
module.exports.createNewRequestByCustomer = (newRequestObj, callback) =>{
  var query = "SELECT sendRequest FROM user_company WHERE user_uid = '" + newRequestObj.user_uid +  "' AND company_cid = '" + newRequestObj.cid + "'";

  pool.query(query, (err, sendRequestPrivilege, field)=>{
    if(err) throw err;

    if(sendRequestPrivilege.length === 0){
      callback(null, {message: "Forbidden, User and Company does not match!"});
    }
    else if(sendRequestPrivilege[0].sendRequest !== '1'){
      callback(null, {message: "Forbidden, This user does not have send request privilege!"});
    }
    else{
      query = "INSERT INTO request (rid, user_id, company_id, status, date) VALUES ?";
      values = [
        [uuid(), newRequestObj.user_uid, newRequestObj.company_cid, newRequestObj.status, newRequestObj.date]
      ]
      pool.query(query, [values], (err, newRequest, field)=>{
        if(err) throw err;

        query = "INSERT INTO request_item (request_rid, type, content, item_unit_uid, item_amount, item_expire_date) VALUES ?";
        requestItems = [];
        newRequestObj.items.forEach( item =>{
          requestItems.push([newRequest.rid, item.type, item.content,  item.unit.unit_uid, item.amount, item.item_expire_date]);
        });
        pool.query(query, [requestItems], (err, newRequest, field)=>{
          if(err) throw err;

          callback(newRequest);
        });
      });
    }
  });
}


/**
* Admin or Mng create new Request
*/
module.exports.createNewRequestByAdmOrMng = (newRequestObj, callback) =>{
  var query = "SELECT sendRequest FROM user_company WHERE user_uid = '" + newRequestObj.user_uid +  "' AND company_cid = '" + newRequestObj.company_cid + "'";
  pool.query(query, (err, sendRequestPrivilege, field)=>{
    if(err) throw err;

    if(sendRequestPrivilege.length === 0){
      callback(null, {message: "Forbidden, User and Company does not match!"});
    }
    else if(sendRequestPrivilege[0].sendRequest !== '1'){
      callback(null, {message: "Forbidden, This user does not have send request privilege!"});
    }
    else{
      query = "INSERT INTO request (rid, user_id, company_id, status, date) VALUES ?";
      let newRequestRid = uuid();
      values = [
        [newRequestRid, newRequestObj.user_uid, newRequestObj.company_cid, newRequestObj.status, newRequestObj.date]
      ]
      pool.query(query, [values], (err, newRequest, field)=>{
        if(err) throw err;
        query = "INSERT INTO request_item (request_rid, activity_type, content, item_unit_uid, item_amount, item_expire_date) VALUES ?";

        requestItems = [];
        newRequestObj.items.forEach( item =>{
          requestItems.push([newRequestRid, item.type, item.content, item.unit.unit_uid, item.amount, item.item_expire_date]);
        });
        pool.query(query, [requestItems], (err, newRequest, field)=>{
          if(err) throw err;

          callback(newRequest);
        });
      });
    }
  });
}

/**
* CUSTOMER GET ALL INVENTORIES
*/
module.exports.getPrivilegeByUserAndCompany = (cid, uid, callback) =>{
  var query = "SELECT * FROM user_company WHERE user_uid = '" + uid + "' AND company_cid ='" + cid + "'";
  pool.query(query, (err, privilege, field)=>{
    if(err) throw err;

    callback(privilege);
  });
}


/**
* CUSTOMER GET ALL INVENTORIES
*/
module.exports.admGetAllEmployeesOfCompany = (cid, callback) =>{
  var query = "SELECT company_cid, sendRequest, viewBill, shortName, type, uid FROM user JOIN user_company ON uid = user_uid WHERE company_cid = '" + cid + "'";
  pool.query(query, (err, employees, field)=>{
    if(err) throw err;

    callback(employees);
  });
}
