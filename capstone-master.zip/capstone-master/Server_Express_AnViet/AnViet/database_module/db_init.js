const pool = require('./dbConnect');
const uuid = require('uuid/v1');
const bcrypt = require('bcrypt');
const initQueue = [];
const fs = require('fs');
const db = require('./db').db;

let test_uid = "";
let test_mng_uid = "";
let test_company_cid = "";
let test_request_rid = "";
let test_inventory_iid = "";

let test_company_cid_1 = "";

const USER_TABLE =
"CREATE TABLE `AnVietDB`.`user` (\
  `uid` VARCHAR(45) NOT NULL,\
  `email` VARCHAR(45) NOT NULL,\
  `password` VARCHAR(100) NOT NULL,\
  `type` VARCHAR(10) NOT NULL,\
  `shortName` VARCHAR(45) NULL,\
  PRIMARY KEY (`uid`),\
  UNIQUE INDEX `uid_UNIQUE` (`uid` ASC) ,\
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) );";

const DAILY_BILL_TABLE =
  "CREATE TABLE `AnVietDB`.`daily_bill` (\
  `daily_bill_company_cid` VARCHAR(45) NOT NULL,\
  `daily_bill_date` VARCHAR(100) NOT NULL,\
  `begin_amount` VARCHAR(45) NOT NULL,\
  `import_normal` VARCHAR(45) NULL,\
  `import_over_time` VARCHAR(45) NULL,\
  `import_holiday` VARCHAR(45) NULL,\
  `export_normal` VARCHAR(45) NULL,\
  `export_over_time` VARCHAR(45) NULL,\
  `export_holiday` VARCHAR(45) NULL,\
  `daily_portFee` VARCHAR(45) NULL,\
  `daily_storageFee` VARCHAR(45) NULL,\
  INDEX `daily_bill_company_cid_idx` (`daily_bill_company_cid` ASC),\
  CONSTRAINT `daily_bill_company_cid`\
    FOREIGN KEY (`daily_bill_company_cid`)\
    REFERENCES `AnVietDB`.`company` (`cid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION);"


const COMPANY_TABLE =
"CREATE TABLE `AnVietDB`.`company` (\
  `cid` VARCHAR(45) NOT NULL,\
  `companyName` VARCHAR(100) NOT NULL,\
  `companyShortName` VARCHAR(45) NOT NULL,\
  `taxCode` VARCHAR(45) NOT NULL,\
  `company_email` VARCHAR(100) NOT NULL,\
  `company_phone` VARCHAR(100) NOT NULL,\
  `address` VARCHAR(45) NOT NULL,\
  `storageFee` VARCHAR(45) NULL,\
  `portFee` VARCHAR(45) NULL,\
  PRIMARY KEY (`cid`),\
  UNIQUE INDEX `cid_UNIQUE` (`cid` ASC) ,\
  UNIQUE INDEX `companyShortName_UNIQUE` (`companyShortName` ASC) );";

const USER_COMPANY_TABLE =
"CREATE TABLE `AnVietDB`.`user_company` (\
  `user_uid` VARCHAR(45) NOT NULL,\
  `company_cid` VARCHAR(45) NOT NULL,\
  `sendRequest` VARCHAR(10) NOT NULL,\
  `viewBill` VARCHAR(10) NOT NULL,\
  INDEX `uid_idx` (`user_uid` ASC) ,\
  INDEX `company_cid_idx` (`company_cid` ASC),\
  CONSTRAINT `user_uid`\
    FOREIGN KEY (`user_uid`)\
    REFERENCES `AnVietDB`.`user` (`uid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `company_cid`\
    FOREIGN KEY (`company_cid`)\
    REFERENCES `AnVietDB`.`company` (`cid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION);";

const PHONE_TABLE =
  "CREATE TABLE `AnVietDB`.`phone` (\
    `uid` VARCHAR(45) NOT NULL,\
    `phoneNumber` VARCHAR(45) NOT NULL,\
    PRIMARY KEY (`uid`),\
    CONSTRAINT `uid`\
      FOREIGN KEY (`uid`)\
      REFERENCES `AnVietDB`.`user` (`uid`)\
      ON DELETE NO ACTION\
      ON UPDATE NO ACTION);";


const UNIT_TABLE =
"CREATE TABLE `AnVietDB`.`item_unit` (\
  `unit_uid` INT NOT NULL AUTO_INCREMENT,\
  `unit_name` VARCHAR(45) NOT NULL,\
  PRIMARY KEY (`unit_uid`),\
  UNIQUE INDEX `iditem_unit_UNIQUE` (`unit_uid` ASC));"

const REQUEST_TABLE =
"CREATE TABLE `AnVietDB`.`request` (\
  `rid` VARCHAR(45) NOT NULL,\
  `user_id` VARCHAR(45) NOT NULL,\
  `company_id` VARCHAR(45) NOT NULL,\
  `status` VARCHAR(45) NULL,\
  `date` VARCHAR(100) NULL,\
  `req_mng_uid` VARCHAR(45) NULL,\
  `req_driver_plate` VARCHAR(45) NULL,\
  `message` VARCHAR(100) NULL,\
  PRIMARY KEY (`rid`),\
  UNIQUE INDEX `rid_UNIQUE` (`rid` ASC) ,\
  INDEX `user_id_idx` (`user_id` ASC) ,\
  INDEX `company_id_idx` (`company_id` ASC) ,\
  CONSTRAINT `user_id`\
    FOREIGN KEY (`user_id`)\
    REFERENCES `AnVietDB`.`user` (`uid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `req_mng_uid`\
    FOREIGN KEY (`req_mng_uid`)\
    REFERENCES `AnVietDB`.`user` (`uid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `company_id`\
    FOREIGN KEY (`company_id`)\
    REFERENCES `AnVietDB`.`company` (`cid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION);"


const REQUEST_ITEM_TABLE =
"CREATE TABLE `AnVietDB`.`request_item` (\
  `item_iid` INT NOT NULL AUTO_INCREMENT,\
  `request_rid` VARCHAR(45) NOT NULL,\
  `activity_type` VARCHAR(45) NULL,\
  `content` VARCHAR(45) NULL,\
  `item_unit_uid` INT NULL,\
  `item_amount` VARCHAR(45) NULL,\
  `item_expire_date`VARCHAR(45) NULL,\
  `item_product_pid` INT NULL,\
  PRIMARY KEY (`item_iid`),\
  CONSTRAINT `request_rid`\
    FOREIGN KEY (`request_rid`)\
    REFERENCES `AnVietDB`.`request` (`rid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `item_product_pid`\
    FOREIGN KEY (`item_product_pid`)\
    REFERENCES `AnVietDB`.`product` (`pid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `item_unit_uid`\
    FOREIGN KEY (`item_unit_uid`)\
    REFERENCES `AnVietDB`.`item_unit` (`unit_uid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION);"


const PRODUCT_TABLE =
"CREATE TABLE `AnVietDB`.`product` (\
  `pid` INT NOT NULL AUTO_INCREMENT,\
  `prodName` VARCHAR(45) NOT NULL,\
  `prodCode` VARCHAR(45) NOT NULL,\
  PRIMARY KEY (`pid`),\
  UNIQUE INDEX `pid_UNIQUE` (`pid` ASC) ,\
  UNIQUE INDEX `prodCode_UNIQUE` (`prodCode` ASC) );";

const INVENTORY_TABLE =
"CREATE TABLE `AnVietDB`.`inventory` (\
  `iid` VARCHAR(45) NOT NULL,\
  `inven_company_cid` VARCHAR(45) NULL,\
  `inven_wh_wid` INT NULL,\
  `inven_prod_pid` INT NULL,\
  `inven_amount` VARCHAR(45) NULL,\
  `inven_unit_uid` INT NULL,\
  `inven_expire_date`VARCHAR(45) NULL,\
  PRIMARY KEY (`iid`),\
  UNIQUE INDEX `iid_UNIQUE` (`iid` ASC),\
  INDEX `inven_company_cid_idx` (`inven_company_cid` ASC),\
  INDEX `inven_prod_pid_idx` (`inven_prod_pid` ASC),\
  INDEX `inven_unit_uid_idx` (`inven_unit_uid` ASC),\
  INDEX `inven_wh_wid_idx` (`inven_wh_wid` ASC),\
  CONSTRAINT `inven_company_cid`\
    FOREIGN KEY (`inven_company_cid`)\
    REFERENCES `AnVietDB`.`company` (`cid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `inven_prod_pid`\
    FOREIGN KEY (`inven_prod_pid`)\
    REFERENCES `AnVietDB`.`product` (`pid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `inven_unit_uid`\
    FOREIGN KEY (`inven_unit_uid`)\
    REFERENCES `AnVietDB`.`item_unit` (`unit_uid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `inven_wh_wid`\
    FOREIGN KEY (`inven_wh_wid`)\
    REFERENCES `AnVietDB`.`warehouse` (`wid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION);";

const ACTIVITY_TABLE =
"CREATE TABLE `AnVietDB`.`activity` (\
  `aid` INT NOT NULL AUTO_INCREMENT,\
  `activity_mng_uid` VARCHAR(45) NOT NULL,\
  `activity_request_rid` VARCHAR(45) NOT NULL,\
  `activity_amount` VARCHAR(45) NOT NULL,\
  `activity_inven_iid` VARCHAR(45) NULL,\
  `activity_date` VARCHAR(100) NOT NULL,\
  `activity_type` VARCHAR(45) NOT NULL,\
  `activity_status` VARCHAR(45) NULL,\
  `activity_work_type` INT NULL,\
  PRIMARY KEY (`aid`),\
  UNIQUE INDEX `aid_UNIQUE` (`aid` ASC),\
  INDEX `activity_request_rid_idx` (`activity_request_rid` ASC),\
  INDEX `activity_inven_iid_idx` (`activity_inven_iid` ASC),\
  INDEX `activity_mng_uid_idx` (`activity_mng_uid` ASC),\
  CONSTRAINT `activity_request_rid`\
    FOREIGN KEY (`activity_request_rid`)\
    REFERENCES `AnVietDB`.`request` (`rid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `activity_inven_iid`\
    FOREIGN KEY (`activity_inven_iid`)\
    REFERENCES `AnVietDB`.`inventory` (`iid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION,\
  CONSTRAINT `activity_mng_uid`\
    FOREIGN KEY (`activity_mng_uid`)\
    REFERENCES `AnVietDB`.`user` (`uid`)\
    ON DELETE NO ACTION\
    ON UPDATE NO ACTION);";

const WAREHOUSE_TABLE =
"CREATE TABLE `AnVietDB`.`warehouse` (\
  `wid` INT NOT NULL AUTO_INCREMENT,\
  `warehouseName` VARCHAR(45) NOT NULL,\
  `warehouseCode` VARCHAR(45) NOT NULL,\
  `avaSpace` VARCHAR(45) NOT NULL,\
  PRIMARY KEY (`wid`),\
  UNIQUE INDEX `wid_UNIQUE` (`wid` ASC) ,\
  UNIQUE INDEX `warehouseCode_UNIQUE` (`warehouseCode` ASC) );";

/*
 * Functions added to the queue will be executed in FIFO order
 */
initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    pool.getConnection((err, connection) => {
        if (err) {
            connection.release();
            console.error("DB initilization failed");
            process.exit(-1);
        }
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    connection.beginTransaction((err) => {
        if (err) {
            throw err;
        }
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "SET FOREIGN_KEY_CHECKS = 0;";
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});


initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "DROP TABLE IF EXISTS user, phone, request, activity, product, warehouse, company, user_company, inventory, request_item, item_unit, daily_bill";

    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});


initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = USER_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = COMPANY_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = USER_COMPANY_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = UNIT_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = PHONE_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = REQUEST_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = REQUEST_ITEM_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = PRODUCT_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = WAREHOUSE_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = INVENTORY_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = ACTIVITY_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = DAILY_BILL_TABLE;
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "SET FOREIGN_KEY_CHECKS = 1;";
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO item_unit (unit_name) VALUES ?";
    let admUid = uuid();
    let values = [
        ['kilogram'],
        ['pound'],
        ['box'],
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO product ( prodName , prodCode) VALUES ?";
    let values = [
        ['Chicken KFC 32 lbs','KFC32'],
        ['Beef Leg 40 lbs','BEEF40'],
        ['Ice Cream Merino 12 packs', 'ICEM12'],
        ['Air Plane Inventory Wings', 'AIRW'],
        ['Egg Roll 20 packs', 'EGGR20'],
        ['FROZEN CHICKEN', 'FCHICK'],
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});


initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO user (uid , email, password, shortName, type) VALUES ?";
    let admUid = uuid();
    let values = [
        [admUid,'admin@gmail.com', bcrypt.hashSync('131464', 10),'Admin Thao','2']
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);

        query = "INSERT INTO phone (uid, phoneNumber) VALUES ?";
        let phones = [
          [admUid, '6084068415']
        ];

        test_mng_uid = admUid;
        connection.query(query, [phones], (err) => {
          if (err) rollbackAndExit(connection, err);
          next(connection, initQueue);
        });
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO user (uid , email, password, shortName, type) VALUES ?";
    let admUid = uuid();
    let values = [
        [admUid,'manager1@gmail.com', bcrypt.hashSync('131464', 10),'Manager John Cena','1']
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);

        query = "INSERT INTO phone (uid, phoneNumber) VALUES ?";
        let phones = [
          [admUid, '608606060']
        ];

        connection.query(query, [phones], (err) => {
          if (err) rollbackAndExit(connection, err);
          next(connection, initQueue);
        });
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO user (uid , email, password, shortName, type) VALUES ?";
    let admUid = uuid();
    let values = [
        [admUid,'manager2@gmail.com', bcrypt.hashSync('131464', 10),'Manager The Rock','1']
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);

        query = "INSERT INTO phone (uid, phoneNumber) VALUES ?";
        let phones = [
          [admUid, '6088814893']
        ];

        connection.query(query, [phones], (err) => {
          if (err) rollbackAndExit(connection, err);
          next(connection, initQueue);
        });
    });
});


initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO company (cid , companyName, company_email, company_phone, companyShortName, taxCode, portFee, storageFee, address) VALUES ?";
    var companyID = uuid();
    let values = [
        [companyID,'Amazon E-commerce Company', 'amazon@gmail.com', '6081112222','Amazon','12345678910','0','0','Amazon.com, Inc. Customer service PO Box 81226 Seattle, WA 98108-1226'],
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);

        let query = "INSERT INTO user (uid , email, password, shortName, type) VALUES ?";
        var admUid = uuid();
        values = [
            [admUid,'customer1@gmail.com', bcrypt.hashSync('131464', 10),'Customer Jim','0']
        ];
        connection.query(query, [values], (err) => {
            if (err) rollbackAndExit(connection, err);

            query = "INSERT INTO phone (uid, phoneNumber) VALUES ?";
            let phones = [
              [admUid, '6089100100']
            ];

            connection.query(query, [phones], (err) => {
              if (err) rollbackAndExit(connection, err);
              let rid_01 = uuid();
              let rid_02 = uuid();
              let rid_03 = uuid();
              let rid_04 = uuid();

              // SET TESTING DATA
              test_request_rid = rid_01;
              test_uid = admUid;
              test_company_cid = companyID;

              query = "INSERT INTO request (rid, user_id, company_id, date, status, req_driver_plate) VALUES ?";
              let requests = [
                [rid_01, admUid, companyID, "Tue Jun 04 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Approved", "31-100B-BA"],
                [rid_02, admUid, companyID, "Thu May 09 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Cancel Pending", ""],
                [rid_03, admUid, companyID, "Wed May 22 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending", ""],
                //[rid_04, admUid, companyID, "Fri May 31 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending",""]
              ];
              connection.query(query, [requests], (err) => {
                if (err) rollbackAndExit(connection, err);

                query = "INSERT INTO user_company (user_uid, company_cid, viewBill, sendRequest) VALUES ?";
                values = [
                  [admUid, companyID, '1','1']
                ]

                connection.query(query, [values], (err) => {
                  if (err) rollbackAndExit(connection, err);

                  query = "INSERT INTO request_item (request_rid, activity_type, item_amount, item_unit_uid, content, item_expire_date) VALUES ?";

                  let values =
                  [
                    [rid_02, "Import", "10000", "2", "Air Plane Inventory Wings", "04/2020"],
                    [rid_02, "Import", "7500", "2" ,"Egg Roll 20 packs", "11/2019"],
                    [rid_03, "Export", "5500", "2", "Egg Roll 20 packs", "11/2019"],
                    [rid_03, "Export", "6000", "2", "Egg Roll 20 packs", "06/2022"],
                    // [rid_04, "Import", "100","2", "KFC32", "10/2021"],
                    // [rid_04, "Import", "900", "1", "FCHICK", "09/2023"]
                  ]
                  connection.query(query, [values], (err) => {
                    if (err) rollbackAndExit(connection, err);

                    query = "INSERT INTO request_item (request_rid, activity_type, item_amount, item_unit_uid, content, item_expire_date, item_product_pid) VALUES ?";
                    let values =
                    [
                      [rid_01, "Export", "2000", "2", "Egg Roll 20 packs" , "11/2019", 5],
                      [rid_01, "Export", "7000" , "2", "Egg Roll 20 packs", "06/2022", 5]
                    ]

                    connection.query(query, [values], (err) => {
                      if (err) rollbackAndExit(connection, err);
                      next(connection, initQueue);
                    });
                  });
                });
              });
            });
        });
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO company (cid , companyName, company_email, company_phone, companyShortName, taxCode, portFee, storageFee, address) VALUES ?";
    var companyID = uuid();
    test_company_cid_1 = companyID;
    let values = [
        [companyID,'Kwik Trip Convenience Store Company', 'kwiktrip@gmail.com', '6082223333','Kwik Trip','10987654321','0','0','Kwik Trip, Inc. 1626 Oak Street PO Box 2107. La Crosse, WI 54602-2107'],
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);
        query = "INSERT INTO user (uid , email, password, shortName, type) VALUES ?";
        var admUid = uuid();
        values = [
            [admUid,'customer2@gmail.com', bcrypt.hashSync('131464', 10),'Customer Nick','0']
        ];
        connection.query(query, [values], (err) => {
            if (err) rollbackAndExit(connection, err);

            query = "INSERT INTO phone (uid, phoneNumber) VALUES ?";
            let phones = [
              [admUid, '6080000000']
            ];

            connection.query(query, [phones], (err) => {
              if (err) rollbackAndExit(connection, err);
              let rid_01 = uuid();
              let rid_02 = uuid();
              let rid_03 = uuid();
              let rid_04 = uuid();
              query = "INSERT INTO request (rid, user_id, company_id , date, status ) VALUES ?";
              let requests = [
                [rid_01, admUid, companyID, "Wed Jun 05 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"],
                [rid_02, admUid, companyID, "Mon Jun 03 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"],
                //[rid_03, admUid, companyID, "Fri May 31 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"],
                //[rid_04, admUid, companyID, "Thu May 30 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"]
              ];
              connection.query(query, [requests], (err) => {
                if (err) rollbackAndExit(connection, err);

                query = "INSERT INTO user_company (user_uid, company_cid, viewBill, sendRequest) VALUES ?";
                values = [
                  [admUid, companyID, '1', '1'],
                ]

                connection.query(query, [values], (err) => {
                  if (err) rollbackAndExit(connection, err);

                  query = "INSERT INTO request_item (request_rid, activity_type, item_amount, item_unit_uid, content, item_expire_date) VALUES ?";

                  let values =
                  [
                    //[rid_01, "Export", "2000", "1", "Chicken KFC 32 lbs", "09/2022"],
                    [rid_01, "Export", "15000", "1", "Chicken KFC 32 lbs", "11/2023"],
                    [rid_01, "Import", "5000", "1", 'Beef Leg 40 lbs', "12/2022"],
                    [rid_02, "Export", "10000", "2", 'Beef Leg 40 lbs', "12/2022"],
                    [rid_02, "Export", "7500", "1", 'Chicken KFC 32 lbs', "11/2023"],
                    // [rid_03, "Import", "5500", "1", 'BEEF40', "11/2019"],
                    // [rid_03, "Export", "6000", "2", 'ICEM12', "09/2021"],
                    // [rid_04, "Import", "100", "1", 'BEEF40', "12/2023"],
                    // [rid_04, "Import", "900", "1", 'BEEF40', "05/2022"],
                  ]
                  connection.query(query, [values], (err) => {
                    if (err) rollbackAndExit(connection, err);
                    next(connection, initQueue);
                  });
                });
              });
            });
        });
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "SELECT cid from company WHERE company_email = 'kwiktrip@gmail.com'";
    connection.query(query, (err, res, fields) => {
        if (err) rollbackAndExit(connection, err);

        let company_cid = res[0].cid;
        query = "SELECT uid from user WHERE email = 'customer1@gmail.com'";

        connection.query(query, (err, res, fields) => {
            if (err) rollbackAndExit(connection, err);

            let user_uid = res[0].uid;

            query = "INSERT INTO user_company (user_uid, company_cid, viewBill, sendRequest) VALUES ?";
            let values = [
              [user_uid, company_cid, '1', '0'],
            ]

            connection.query(query, [values], (err) => {
              if (err) rollbackAndExit(connection, err);
              let rid_01 = uuid();
              let rid_02 = uuid();
              let rid_03 = uuid();
              query = "INSERT INTO request (rid, user_id, company_id, date, status ) VALUES ?";
              let requests = [
                [rid_01, user_uid, company_cid, "Wed May 08 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"],
                [rid_02, user_uid, company_cid, "Wed May 22 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"],
                //[rid_03, user_uid, company_cid, "Mon May 20 2019 00:00:00 GMT-0500 (Central Daylight Time)", "Pending"],
              ];
              connection.query(query, [requests], (err) => {
                if (err) rollbackAndExit(connection, err);
                query = "INSERT INTO request_item (request_rid, activity_type, item_amount, item_unit_uid, content, item_expire_date) VALUES ?";

                let values =
                [
                  [rid_01, "Import", "7000", "2", "Chicken KFC 32 lbs", "11/2023"],
                  [rid_01, "Import", "35000", "2" ,"BEEF40", "12/2022"],
                  [rid_02, "Export", "5500", "2", "Chicken KFC 32 lbs", "11/2023"],
                  [rid_02, "Export", "10000", "2", "Beef Leg 40 lbs", "12/2022"],
                  //[rid_02, "Export", "700", "1", "FROZEN CHICKEN", "04/2020"],
                  // [rid_03, "Import", "5900", "1", "FROZEN CHICKEN", "02/2021"],

                  // [rid_03, "Import", "6000", "1", "FROZEN CHICKEN", "07/2019"]
                ]
                connection.query(query, [values], (err) => {
                  if (err) rollbackAndExit(connection, err);
                  next(connection, initQueue);
                });
            });
          });
        });
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "INSERT INTO warehouse (warehouseName , warehouseCode,avaSpace) VALUES ?";
    let values = [
        ['An Viet 1 Kho A','AV1A','10000'],
        ['An Viet 1 Kho B','AV1B','5600'],
        ['An Viet 1 Kho C', 'AV1C','11000'],
        ['An Viet 2 Kho 1','AV21','1100'],
        ['An Viet 2 Kho 2','AV22','10500'],

    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();
    let query = "SELECT cid FROM company";
    connection.query(query, (err, companies_uid, fields) => {
      if (err) rollbackAndExit(connection, err);

      test_inventory_iid_1 = uuid();
      test_inventory_iid_2 = uuid();

      query = "INSERT INTO inventory (iid, inven_company_cid, inven_prod_pid, inven_wh_wid, inven_amount, inven_unit_uid, inven_expire_date) VALUES ?";
      let values = [
          // [uuid(),companies_uid[0].cid, 1, 2, "2000", 2, "06/2021"],
          // [uuid(),companies_uid[0].cid, 2, 2, "1900", 2, "08/2022"],
          // [uuid(),companies_uid[0].cid, 3, 2, "2500", 2, "05/2021"],
          // [uuid(),companies_uid[0].cid, 4, 2, "3950", 2, "06/2021"],
          //testing
          [test_inventory_iid_1, companies_uid[0].cid, 5, 2, "55000", 2, "11/2019"],
          [test_inventory_iid_2, companies_uid[0].cid, 5, 2, "100000", 2, "06/2022"],
          //
          [uuid(),companies_uid[0].cid, 5, 4, "20000", 2, "11/2019"],
          [uuid(),companies_uid[0].cid, 4, 4, "15000", 2, "04/2020"],
          // [uuid(),companies_uid[0].cid, 5, 6, "1000", 2, "04/2020"],
          // [uuid(),companies_uid[1].cid, 1, 2, "2000", 2, "04/2021"],
          // [uuid(),companies_uid[1].cid, 2, 2, "1900", 2, "05/2022"],
          [uuid(),companies_uid[1].cid, 1, 2, "25000", 2, "11/2023"],
          [uuid(),companies_uid[1].cid, 2, 2, "39500", 2, "12/2022"],
          // [uuid(),companies_uid[1].cid, 5, 2, "1500", 2, "02/2021"],
          // [uuid(),companies_uid[1].cid, 1, 4, "7000", 2, "03/2022"],
          // [uuid(),companies_uid[1].cid, 3, 4, "2000", 2, "03/2022"],
          // [uuid(),companies_uid[1].cid, 4, 5, "1500", 2, "02/2021"],
          // [uuid(),companies_uid[1].cid, 5, 6, "1000", 2, "10/2021"],
      ];
      connection.query(query, [values], (err) => {
          if (err) rollbackAndExit(connection, err);
          next(connection, initQueue);
      });
    });
});

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();

    query = "INSERT INTO activity (activity_mng_uid, activity_request_rid, activity_amount, activity_inven_iid, activity_date, activity_type, activity_status, activity_work_type) VALUES ?";
    let values = [
      [test_mng_uid, test_request_rid, "2000" , test_inventory_iid_1, "Tue Jul 02 2019 15:35:34 GMT-0500 (Central Daylight Time)", "Export", "Approved", 0],
      [test_mng_uid, test_request_rid, "7000" , test_inventory_iid_2, "Tue Jul 02 2019 15:35:34 GMT-0500 (Central Daylight Time)", "Export", "Approved", 0],
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });

});


// initQueue.unshift((connection, initQueue) => {
//     let next = initQueue.pop();
//
//     query = "INSERT INTO daily_bill (daily_bill_company_cid, daily_bill_date, begin_amount) VALUES ?";
//     let values = [
//
//     ];
//     connection.query(query, [values], (err) => {
//         if (err) rollbackAndExit(connection, err);
//         next(connection, initQueue);
//     });
// });

initQueue.unshift((connection, initQueue) => {
    let next = initQueue.pop();

    query = "INSERT INTO daily_bill (daily_bill_company_cid, daily_bill_date, begin_amount, import_normal, import_over_time,import_holiday,export_normal, export_over_time, export_holiday, daily_portFee, daily_storageFee) VALUES ?";
    let values = [
      [test_company_cid, "Thu Jun 27 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Fri Jun 28 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jun 29 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jun 30 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jul 01 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Tue Jul 02 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jun 01 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jun 02 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jun 03 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Tue Jun 04 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Wed Jun 05 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Thu Jun 06 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Fri Jun 07 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jun 08 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jun 09 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jun 10 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Tue Jun 11 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Wed Jun 12 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Thu Jun 13 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Fri Jun 14 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jun 15 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jun 16 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jun 17 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Tue Jun 18 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Wed Jun 19 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Thu Jun 20 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Fri Jun 21 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jun 22 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jun 23 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jun 24 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Tue Jun 25 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Wed Jun 26 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],

      [test_company_cid, "Wed Jul 03 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Thu Jul 04 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Fri Jul 05 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jul 06 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jul 07 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jul 08 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Tue Jul 09 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Wed Jul 10 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Thu Jul 11 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Fri Jul 12 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sat Jul 13 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Sun Jul 14 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
      [test_company_cid, "Mon Jul 15 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0,1.5,1.1],
    ];
    connection.query(query, [values], (err) => {
        if (err) rollbackAndExit(connection, err);
        next(connection, initQueue);
    });
});
//
// initQueue.unshift((connection, initQueue) => {
//     let next = initQueue.pop();
//     query = "DELETE FROM daily_bill WHERE daily_bill_date = 'Tue Jun 11 2019 00:00:00 GMT-0500 (Central Daylight Time)'";
//
//     connection.query(query, (err) => {
//         if (err) rollbackAndExit(connection, err);
//         query = "INSERT INTO daily_bill (daily_bill_company_cid, daily_bill_date, begin_amount, import_normal, import_over_time,import_holiday,export_normal, export_over_time, export_holiday) VALUES ?";
//         let values = [
//           [test_company_cid, "Tue Jun 11 2019 00:00:00 GMT-0500 (Central Daylight Time)", 190000, 0,0,0,0,0,0],
//         ];
//         connection.query(query, [values], (err) => {
//             if (err) rollbackAndExit(connection, err);
//             next(connection, initQueue);
//         });
//     });
// });

// ### END TEST_DATA

initQueue.unshift((connection, initQueue) => {
    connection.commit((err) => {
        if (err) rollbackAndExit(connection, err);
        connection.release();
        console.log("Database values initialized");
        process.exit(0);
    });
});

function rollbackAndExit(connection, err) {
    connection.rollback(() => {
        console.error("Error: " + err.message);
        connection.release();
        throw err;
    });
}


let executeQueue = initQueue.pop();
executeQueue(undefined, initQueue);
