// var mysql = require('mysql');
// var passport = require('passport');
// var bcrypt = require('bcrypt');
//
// var con = mysql.createConnection({
//   // host: "anvietdb.c2v3urekreuy.us-east-2.rds.amazonaws.com",
//   // user: "hphuong1995",
//   // port: 3306,
//   host: "localhost",
//   user: "root",
//   password: "Hphuong131464",
//   database: "AnVietDB",
//   insecureAuth : true
// });
//
// con.connect(function(err) {
//   if (err) throw err;
//   console.log("Connected!");
// });
//
// module.exports = con;
//

const fs = require("fs");
const mysql = require('mysql');
const { MysqlError, PoolConnection } = require('mysql');
const { FieldInfo, GeometryType, Pool, PoolConfig } = require("mysql");
let pool = null;

if (fs.existsSync("./.dbtoken")) {
    console.log("attempting to connect...");
    const connectionObject = JSON.parse(fs.readFileSync("./.dbtoken").toString());
    connectionObject.connectionLimit = 10;
    connectionObject.typeCast = customCaster;
    pool = mysql.createPool( connectionObject );
} else {
    console.log(".dbtoken file not found, creating .dbtoken");
    const connectionObject = {
      host: "localhost",
      user: "root",
      password: "Hphuong131464",
      database: "AnVietDB",
      insecureAuth : true
    };
    fs.writeFileSync("./.dbtoken", JSON.stringify(connectionObject, null, 4));
    console.log("Please fill out .dbtoken with the database connection info");
    process.exit(0);
}

pool.getConnection((err, connection) => {
    if (err) {
        console.error(err);
    }
    if (connection) {
        console.log("Established connection with database");
        connection.release();
    }
});

function customCaster( field, next){
    if (field.type === "BIT") {
        // convert the field into a list of bits, least significant at index 0
        const bytes = field.buffer();
        return bytes[0] === 1;
    }
    return next();
}

module.exports = pool; // here for javascript compatibility
