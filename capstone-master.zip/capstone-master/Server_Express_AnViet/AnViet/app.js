var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');
var schedule = require('node-schedule');

var db = require('./database_module/dbConnect');

// Authentication packages
var session = require('express-session');

var passport = require('passport'),
    LocalStrategy = require('passport-local').Strategy;
var bcrypt = require('bcrypt');


var MySQLStore = require('express-mysql-session')(session);



var app = express();

const ADMIN = '2';
const MANAGER = '1';
const CUSTOMER = '0';


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// UPDATE DAILY BILL
schedule.scheduleJob('0 0 0 * * *', () => {
  let query = "SELECT * FROM company;";
  db.query(query, (err, companies, field)=>{
    if(err) throw err;

    query = "SELECT * FROM inventory;";
    db.query(query, (err, inventories, field)=>{
      if(err) throw err;

      let daily_bills = getDailyInventoryInStore(companies, inventories);

      let yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      yesterday.setHours(0,0,0,0);
      let today = new Date();
      today.setHours(0,0,0,0);

      query = "SELECT * FROM activity JOIN inventory ON activity_inven_iid = iid \
              WHERE activity_status = 'Validated' AND activity_date ='" + yesterday.toString() + "';";

      db.query(query, (err, activities, field)=>{
        if(err) throw err;

        let daily_import_export = getDailyImportExport(companies, activities);

        query = "SELECT * FROM daily_bill JOIN company ON daily_bill_company_cid = cid WHERE daily_bill_date = '" + yesterday.toString() + "';";
        db.query(query, (err, bills, field)=>{
          if(err) throw err;
          let yesterday_bill_update = generateYesterdayBill(daily_import_export, bills);

          query = "DELETE FROM daily_bill WHERE daily_bill_date = '" + yesterday.toString() + "';";

          db.query(query, (err, activities, field)=>{
            if(err) throw err;

            query = "INSERT INTO daily_bill (daily_bill_company_cid, daily_bill_date, begin_amount, import_normal, import_over_time,\
                     import_holiday, export_normal, export_over_time, export_holiday, daily_portFee, daily_storageFee) VALUES ?";
            let values = [];
            yesterday_bill_update.forEach( bill =>{
              values.push([bill.cid, yesterday.toString(), bill.begin_amount, bill.import_normal, bill.import_over_time, bill.import_holiday,
                bill.export_normal, bill.export_over_time, bill.export_holiday, bill.portFee, bill.storageFee]);
            });

            db.query(query,[values], (err, company, field)=>{
                 if(err) throw err;
            });
          });
        });
      });
    });
  });
}); // run everyday at midnight


schedule.scheduleJob('0 0 0 * * *', () => {
  let query = "SELECT * FROM company;";
  db.query(query, (err, companies, field)=>{
    if(err) throw err;

    query = "SELECT * FROM inventory;";
    db.query(query, (err, inventories, field)=>{
      if(err) throw err;

      let daily_bills = getDailyInventoryInStore(companies, inventories);

      let today = new Date();
      today.setHours(0,0,0,0);
      query = "INSERT INTO daily_bill (daily_bill_company_cid, daily_bill_date, begin_amount) VALUES ?";
      let values = [];
      daily_bills.forEach( bill =>{
        values.push([bill.cid, today.toString(), bill.amount]);
      });

      db.query(query,[values], (err, company, field)=>{
        if(err) throw err;

      });
    });
  });
}); // run everyday at midnight


generateYesterdayBill = function(daily_import_export, bills){
  bills.forEach( bill =>{
    daily_import_export.forEach(daily =>{
      if(daily.cid === bill.daily_bill_company_cid){
        daily.begin_amount = bill.begin_amount;
        daily.portFee = bill.portFee;
        daily.storageFee = bill.storageFee;
      }
    });
  });
  return daily_import_export;
}

getDailyImportExport = function(companies, activities){
  let retList = [];
  companies.forEach( company =>{
    let import_normal = 0;
    let export_normal = 0;
    let import_over_time = 0;
    let export_over_time = 0;
    let import_holiday = 0;
    let export_holiday = 0;
    activities.forEach( activity =>{
      if(activity.inven_company_cid === company.cid){
        if(activity.activity_type === 'Import'){
          if(activity.activity_work_type === 0){
            import_normal = import_normal + parseInt(activity.activity_amount);
          }
          else if(activity.activity_work_type === 1){
            import_over_time = import_over_time + parseInt(activity.activity_amount);
          }
          else if(activity.activity_work_type === 2){
            import_holiday = import_holiday + parseInt(activity.activity_amount);
          }
        }
        else if( activity.activity_type === 'Export' ){
          if(activity.activity_work_type === 0){
            export_normal = export_normal + parseInt(activity.activity_amount);
          }
          else if(activity.activity_work_type === 1){
            export_over_time = export_over_time + parseInt(activity.activity_amount);
          }
          else if(activity.activity_work_type === 2){
            export_holiday = export_holiday + parseInt(activity.activity_amount);
          }
        }
      }
    });
    retList.push({
      cid: company.cid,
      import_normal: import_normal,
      import_over_time: import_over_time,
      import_holiday: import_holiday,
      export_normal: export_normal,
      export_over_time: export_over_time,
      export_holiday: export_holiday,
    });
  });

  return retList;
}

generateCompanyIdQuery = function(companies){
  let retStr = "";

  companies.forEach( company =>{
    retStr = retStr + " '" + company.cid + "' ,";
  });

  return retStr.substr(0,retStr.length - 2);
}

generateDailyBillAmountQuery = function(daily_bills){
  let retStr = "CASE ";

  daily_bills.forEach( bill =>{
    retStr = retStr + "WHEN daily_bill_company_cid = '" + bill.cid + "' THEN '" + bill.amount + "' ";
  });

  retStr = retStr + " END";
  return retStr;
}


getDailyInventoryInStore = function(companies, inventories){
  let retInvenList = [];
  companies.forEach( company =>{
    let amount = 0;
    inventories.forEach( inventory =>{
      if(inventory.inven_company_cid === company.cid){
        amount = amount + parseInt(inventory.inven_amount);
      }
    });
    retInvenList.push({
      cid: company.cid,
      amount: amount
    });
  });

  return retInvenList;
}

// END UPDATE DAILY BILL

var options = {
  host: "anvietdb.c2v3urekreuy.us-east-2.rds.amazonaws.com",
  user: "hphuong1995",
  port: 3306,
  password: "Hphuong131464",
  database: "AnVietDB",
  insecureAuth : true
};

var sessionStore = new MySQLStore(options);

app.use( session( {
    cookie: {
        httpOnly: true,
        maxAge: 10 * 60 * 100000,
    },
    resave: false,
    secret: "anvietcoldstorage",
    store: sessionStore,
    saveUninitialized: false
} ) );

app.use(passport.initialize());
app.use(passport.session());

app.use(function (req, res, next){
    res.locals.isAuthenticated = req.isAuthenticated();
    next();
});

app.use(expressValidator());

var auth = require('./routes/authenticate');
var route = require('./routes/route');
var admin_Route = require('./routes/admin_route');
var manager_Route = require('./routes/manager_route');

const checkMngRole = function(req, res, next) {
  if(req.user && (req.user.type === ADMIN || req.user.type === MANAGER)){
    next();
  }
  else{
    res.status(403).send({message: 'Forbidden'});
  }
}

const checkAdmRole = function(req, res, next) {
  if(req.user && req.user.type === ADMIN){
    next();
  }
  else{
    res.status(403).send({message: 'Forbidden'});
  }
}

const checkUserAuthenticated = function(req, res, next) {
  if(req.user){
    next();
  }
  else{
    res.status(403).send({message: 'Forbidden'});
  }
}

//Route
app.use('/', auth);
app.use('/api/v1/', checkUserAuthenticated , route);
app.use('/api/v1/admin' , checkAdmRole, admin_Route);
app.use('/api/v1/manager', checkMngRole, manager_Route);

// passport strategy
passport.use(new LocalStrategy(
  function(email, password, done) {
    db.query('SELECT * FROM user WHERE email = ?', [email] , (err, results, fields)=>{
      if(err) done(err);
      // If no user found => wrong username
      if(results.length === 0){
        done(null,false);
      }
      else{
        const hash = results[0].password.toString();
        const user = results[0];
        // Compare the password
        bcrypt.compare( password, hash, (err, response) =>{
          if( response === true){
            const user_id = results[0].uid.toString();
            // pull the phone of authenticated User
            let phoneQuery = "SELECT * from phone WHERE uid = ?";
            db.query(phoneQuery, [user_id], (err, phoneResults, fields)=>{
              if(err) done(err);
              user.phone = phoneResults[0].phoneNumber;
              // Get all related companies of authenticated User
              let companiesQuery = "SELECT company_cid, companyName, companyShortName, viewBill, sendRequest\
                                    from user_company JOIN company ON company_cid = cid WHERE user_uid = ? ";
              db.query(companiesQuery, [user_id], (err, companiesResult, fields)=>{
                if(err) done(err);
                user.companies = companiesResult;
                done(null, user);
              });
            });
          }
          else{
            done(null, false);
          }
        });
      }
    });
  }
));



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

console.log("now running");
module.exports = app;
