var express = require('express');
var router = express.Router();
var db = require('./../database_module/db');
var expressValidator = require('express-validator');

router.put("/accounts/:uid", (req, res, next) => {
  if(req.user.uid !== req.params.uid){
    res.status(403).send({message: 'Forbidden'});
    return;
  }
  else{
    db.updateAccountInfo(req.body, (newUserInfo, err)=>{
      if(err){
        res.status(500).send(err);
      }
      else{
        //console.log(newUserInfo);
        res.status(200).send(newUserInfo);
      }
    });
  }
});

router.get('/requests', (req, res, next) => {
  if(req.user.uid !== req.query.uid){
    res.status(403).send({message: 'Forbidden'});
    return;
  }
  else{
    if(req.query.startDate){
      req.query.startDate= req.query.startDate.replace('%', ' ')
    }
    if(req.query.endDate){
      req.query.endDate= req.query.endDate.replace('%', ' ')
    }

    db.getAllRequestsByCus(req.query, req.query.uid, req.query.cid ,(requests, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(requests);
      }
    });
  }
});

router.get('/bills', (req, res, next) => {
  if(req.user && req.user.type === '1'){
    res.status(403).send({message: 'Forbidden'});
    return;
  }
  else{
    if(req.query.startDate){
      req.query.startDate= req.query.startDate.replace('%', ' ')
    }
    if(req.query.endDate){
      req.query.endDate= req.query.endDate.replace('%', ' ')
    }

    if(req.user.type === '0'){
      db.generateBillByCus(req.user, req.query, (bills, err) =>{
        if(err){
          res.status(400).send(err);
        }
        else{
          res.status(200).send(bills);
        }
      });
    }
    else{
      db.generateBillByAdm(req.query, (bills, err) =>{
        if(err){
          res.status(400).send(err);
        }
        else{
          res.status(200).send(bills);
        }
      });
    }
  }
});

router.get('/requests/:rid',(req, res, next) => {
  db.getOneRequestsByCus(req.params.rid ,(request, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(request);
    }
  });
});

router.put('/requests/:rid',(req, res, next) => {
  req.body.user = req.user;
  console.log(req.body.status);
  if(req.body.status === "Canceling"){
    db.cancelRequestByCustomer(req.params.rid, req.body ,(request, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(request);
      }
    });
  }
  else{
    res.status(500).send({message: "Customer can not do any other operation to Request except cancel request"});
  }
});

router.post('/requests',(req, res, next) => {
  let currentCompany = null;
  req.user.companies.forEach( company =>{
    if(company.company_id === req.body.cid){
      currentCompany = company;
    }
  });

  if(currentCompany && currentCompany.sendRequest === '0'){
    res.status(403).send({ message: "Forbidden"});
  }
  else{
    db.createNewRequestByCustomer(req.body, (request, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(request);
      }
    });
  }
});

router.get('/units',(req, res, next) => {
  db.getUnitListFromServer( (units, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(units);
    }
  });
});

router.get('/inventories', (req, res, next) => {
  if(req.user.uid !== req.query.uid){
    res.status(403).send({ message: "Forbidden"});
  }
  else{
    db.getAllInventoriesByCus( req.query, (inventories, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(inventories);
      }
    });
  }
});

function authenticationMiddleware(){
  return (req,res,next) =>{
    console.log( `req.session.passport.user : ${JSON.stringify(req.session.passport)}`);
    if( req.isAuthenticated()) return next();
    // somehow redirect to login
    res.status(400).send({redirect: "/login"});
  }
}

module.exports = router;
