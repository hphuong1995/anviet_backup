var db = require('./../database_module/db');
var express = require('express');
var router = express.Router();

router.get('/accounts', (req, res, next) =>{
  db.getAllAccountsAsManager( (accounts, err) =>{
    if( err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(accounts);
    }
  });
});


router.put('/requests/:rid', (req, res, next) =>{
  console.log(req.body.status);
  if(req.body.updatingStatus === "Denied"){
    db.denyRequestByMngOrAdm(req.params.rid , req.body, (requests, err) =>{
      if( err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(requests);
      }
    });
  }
  else if(req.body.updatingStatus === "Approved"){
    db.approveRequestByMngOrAdm(req.params.rid , req.body, (requests, err) =>{
      if( err){
        res.status(400).send(err);
      }
      else{
        res.status(200).send(requests);
      }
    });
  }
  else if(req.body.updatingStatus === "Approve Cancel"){
    db.approveCancelationByMngOrAdm( req.params.rid, req.body, (requests, err) =>{
      if( err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(requests);
      }
    });
  }
  else if(req.body.updatingStatus === "Deny Cancel"){
    db.denyCancelationByMngOrAdm( req.params.rid, req.body, (requests, err) =>{
      if( err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(requests);
      }
    });
  }
  else if(req.body.updatingStatus === "Validated"){
    db.validateByMngOrAdm( req.params.rid, req.body, (requests, err) =>{
      if( err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(requests);
      }
    });
  }
  else{
    res.status(400).send({message: "Unknown status"});
  }
});

router.get('/products', (req, res, next) => {
  db.getAllProdsByAdmOrMng( (products, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(products);
    }
  });
});

router.get('/warehouses', (req, res, next) => {
  db.getAllWareHousesByAdmOrMng( (warehouses, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(warehouses);
    }
  });
});



router.get('/companies/:cid/products',(req, res, next) => {
  db.getAllProductOfACompany(req.params.cid, (products, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(products);
    }
  });
});


router.put('/request_items/:iid', (req, res, next ) => {
  db.updateRequestItemProductId( req.params.iid, req.body, (request, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(request);
    }
  });
});


router.get('/companies',(req, res, next) => {
  if(req.query.uid){
    db.getAllCompaniesRelateToAnUserByAdmOrMng(req.query, (companies, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(companies);
      }
    });
  }
  else{
    db.getAllCompaniesByAdmOrMng( (companies, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(companies);
      }
    });
  }
});

router.get('/companies/:cid',(req, res, next) => {
  db.getACompanyByMng(req.params.cid, (companies, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(companies);
    }
  });
});

// router.get('/companies/:cid/employees',(req, res, next) => {
//   db.getAllEmployeesOfCompanyByAdmOrMng(req.params.cid, (employess, err) =>{
//     if(err){
//       res.status(500).send(err);
//     }
//     else{
//       res.status(200).send(employess);
//     }
//   });
// });

router.put("/accounts/:uid", (req, res, next) => {
  console.log(req.user.type);
  if(req.user.type !== '2' && req.body.type === '2'){
    res.status(403).send({message: 'Forbidden'});
  }
  else{
    db.updateAccountInfo(req.body, (newUserInfo, err)=>{
      if(err){
        res.status(500).send(err);
      }
      else{
        //console.log(newUserInfo);
        res.status(200).send(newUserInfo);
      }
    });
  }
});

router.get('/requests/:rid',(req, res, next) => {
  db.getOneRequestsByAdmOrMng(req.params.rid ,(request, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(request);
    }
  });
});

router.get('/companies/:cid/employees/:uid', (req, res, next ) => {
  db.getPrivilegeByUserAndCompany(req.params.cid, req.params.uid, (privilege , err ) =>{
    if(err){
      res.status(500).send(err)
    }
    else{
      res.status(200).send(privilege);
    }
  });
});

router.post('/requests',(req, res, next) => {
  db.createNewRequestByAdmOrMng(req.body, (request, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(request);
    }
  });
  // }
});

router.get('/inventories', (req, res, next) => {
  console.log(req.query);
  db.getAllInventoriesByAdmAndMng( req.query, (inventories, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(inventories);
    }
  });
});

router.get('/requests', (req, res, next) => {
  if(req.query.startDate){
    req.query.startDate= req.query.startDate.replace('%', ' ')
  }
  if(req.query.endDate){
    req.query.endDate= req.query.endDate.replace('%', ' ')
  }

  db.getAllRequests( req.query, (requests, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(requests);
    }
  });
});

router.post('/activities', (req, res, next) => {
  if(req.body.activity_newInven_warehouse){
    db.createNewInvenBeforeCreateActivity( req.body, (activities, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(activities);
      }
    });
  }
  else{
    db.createNewActivityForRequest( req.body, (activities, err) =>{
      if(err){
        res.status(500).send(err);
      }
      else{
        res.status(200).send(activities);
      }
    });
  }
});

router.delete('/activities/:aid', (req, res, next) => {
  console.log(req.query);
  let activityObj = {
    aid : req.params.aid,
    inven_amount: req.query.activity_inven_amount,
    activity_inven_iid: req.query.activity_inven_iid,
    activity_request_rid: req.query.activity_request_rid
  }
  db.deleteActivityByAdmOrMng( activityObj, (activities, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(activities);
    }
  });
});

router.delete('/products/:pid', (req, res, next) => {

  db.deleteProduct( req.params.pid, (products, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(products);
    }
  });
});

router.get('/activities', (req, res, next) => {
  if(req.query.startDate){
    req.query.startDate= req.query.startDate.replace('%', ' ')
  }
  if(req.query.endDate){
    req.query.endDate= req.query.endDate.replace('%', ' ')
  }

  db.getAllActivitiesByAdmMng(req.query, (activities, err) =>{
    if(err){
      res.status(500).send(err);
    }
    else{
      res.status(200).send(activities);
    }
  });
});


router.post('/products', (req, res, next ) => {
  db.createProductByAdmOrMng(req.body,(products, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(products);
    }
  });
});

module.exports = router;
