var db = require('./../database_module/db');
var express = require('express');
var router = express.Router();

router.get('/accounts', (req, res, next) =>{
  db.getAllAccountsAsAdmin( (accounts, err) =>{
    if( err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(accounts);
    }
  });
});

router.get('/accounts/:uid', (req, res, next) => {
  db.getAnAccountAsAdmin( req.params.uid, (account, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(account);
    }
  });
});

router.get('/products', (req, res, next) => {
  db.getAllProdsByAdmOrMng( (products, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(products);
    }
  });
});

router.put('/products/:pid', (req, res, next) => {
  db.updateProduct(req.body, (products, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(products);
    }
  });
});

router.get('/warehouses', (req, res, next) => {
  db.getAllWareHousesByAdmOrMng( (warehouses, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(warehouses);
    }
  });
});

router.put('/warehouses/:wid', (req, res, next) => {
  db.updateWarehouse(req.body, (warehouses, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(warehouses);
    }
  });
});

router.delete('/warehouses/:wid', (req, res, next) => {
  db.deleteWarehouse(req.params.wid, (warehouses, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(warehouses);
    }
  });
});

router.put('/companies/:cid', (req, res, next) => {
  db.updateCompanyInfoByAdm( req.body, (newCompanyInfo, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(newCompanyInfo);
    }
  });
});


router.get('/companies',(req, res, next) => {
  db.getAllCompaniesByAdmOrMng( (companies, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(companies);
    }
  });
});

router.post('/accounts/:uid', (req, res, next) => {
  db.addCompanyToAccountByAdm( req.params.uid, req.body.cid, (newEntry, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(newEntry);
    }
  });
});

router.delete('/accounts/:uid', (req, res, next) => {
  db.deleteCompanyFromUserByAdm( req.params.uid, req.query.cid, (deletedEntry, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(deletedEntry);
    }
  });
});

router.get('/companies/:cid', (req, res, next) => {
  db.getACompanyByAdm( req.params.cid, (company, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(company);
    }
  });
});


router.get('/companies/:cid/employees' , (req, res, next ) => {
  db.admGetAllEmployeesOfCompany(req.params.cid ,(employees, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(employees);
    }
  });
});

router.put('/companies/:cid/employees/:uid', (req, res, next ) => {
  if(req.body.viewBill){
    db.updateCustomerViewBillRight(req.params.cid, req.params.uid, req.body ,(employees, err) =>{
      if(err){
        res.status(400).send(err);
      }
      else{
        res.status(200).send(employees);
      }
    });
  }
  else{
    db.updateCustomerSendRequestRight(req.params.cid, req.params.uid, req.body ,(employees, err) =>{
      if(err){
        res.status(400).send(err);
      }
      else{
        res.status(200).send(employees);
      }
    });
  }
});


router.post('/warehouses', (req, res, next ) => {
  db.createNewWarehouseByAdm(req.body,(warehouses, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(warehouses);
    }
  });
});

router.post('/company', (req, res, next ) => {
  db.createNewCompany(req.body,(companies, err) =>{
    if(err){
      res.status(400).send(err);
    }
    else{
      res.status(200).send(companies);
    }
  });
});

module.exports = router;
