var express = require('express');
var router = express.Router();
var db = require('./../database_module/db');
var expressValidator = require('express-validator');
var bcrypt = require('bcrypt');
const saltRounds = 10;
var passport = require('passport');



router.post('/api/v1/register', function( req, res, next){
  req.checkBody('email', 'Username field can not be empty').notEmpty();
  req.checkBody('password', 'password field can not be empty').notEmpty();
  // req.checkBody('company', 'company field can not be empty').notEmpty();
  req.checkBody('phone', 'phoneNumber field can not be empty').notEmpty();

  const errors = req.validationErrors();

  if(errors){
    res.status(200).send({'message': errors});
  }

  var email = req.body.email;
  var password = req.body.password;
  // var company = req.body.company;
  var phone = req.body.phone;

  bcrypt.hash(password, saltRounds, function(err, hash) {
    // Store hash in your password DB.
    db.userRegister(email, hash, 0, phone, (user, error) => {
      if(error) {
        res.status(500).send(error);
      }
      else{
        res.status(200).send(user);
      }
    });
  });
});

router.post('/api/v1/login',
  passport.authenticate('local', { failureRedirect: 'login' }),
  function(req, res) {
    delete req.user.password;
    req.user.success = true;
    res.status(200).send(req.user);}
);

router.get('/api/v1/logout',function(req, res){
  req.logout();
  req.session.destroy();
  res.status(200).send({'success' : true, 'redirect' : 'login'});
});


passport.serializeUser(function(user_id, done) {
  done(null, user_id);
});

passport.deserializeUser(function(user_id, done) {
  done(null, user_id);
});

module.exports = router;
